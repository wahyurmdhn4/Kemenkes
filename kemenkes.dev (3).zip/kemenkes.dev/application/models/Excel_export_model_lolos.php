<?php
class Excel_export_model_lolos extends CI_Model
{
 function fetch_data()
 {
  $this->db->order_by("id_paket", "DESC");
  $query = $this->db->get("vw_lolos");
  return $query->result();
 }

 
}
