<?php
	class Model_Auth extends CI_Model {

		function __construct(){
			parent::__construct();
		}

		//cek keberadaan user di sistem
		function login($username,$password){
			$query = ("select 
									id_user,
									username,
									password,
									level,
									nama
								from tb_user
								where username ='".$username."' and `password` = '".$password."'
					");
			return $this->db->query($query);
		}
		
	}
?>
