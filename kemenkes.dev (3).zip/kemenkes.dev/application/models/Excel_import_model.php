<?php
class Excel_import_model extends CI_Model
{
function view(){
    return $this->db->get('penawaran_import')->result(); // Tampilkan semua data yang ada di tabel siswa
  }

/*	function select()
	{
		$this->db->order_by('id_paket', 'DESC');
		$query = $this->db->get('penawaran_import');
		return $query;
	}*/

	function upload_file($filename){
    $this->load->library('upload'); // Load librari upload
    
    $config['upload_path'] = './excel/';
    $config['allowed_types'] = 'xlsx';
    $config['max_size']  = '2048';
    $config['overwrite'] = true;
    $config['file_name'] = $filename;
  
    $this->upload->initialize($config); // Load konfigurasi uploadnya
    if($this->upload->do_upload('file')){ // Lakukan upload dan Cek jika proses upload berhasil
      // Jika berhasil :
      $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
      return $return;
    }else{
      // Jika gagal :
      $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
      return $return;
    }
  }

	function insert($data)
	{
		$this->db->insert_batch('penawaran_import', $data);
	}
}
