<?php
class Model_penilaian_paket extends CI_Model
{
	var $updateTable = 'penawaran_import';
	var $table = 'vw_penilaian_paket';
	var $column_order = array('id_paket','nama_zat_aktif','kemasan_syarat','rko_nasional','provinsi','rko_prov','hps_provinsi'); //set column field database for datatable orderable
	var $column_search = array('id_paket','nama_zat_aktif','kemasan_syarat','rko_nasional','provinsi','rko_prov','hps_provinsi'); //set column field database for datatable searchable 
	var $order = array('rko_prov' => 'desc'); // default order 
	private function _get_datatables_query()
	{
		
		//add custom filter here
		if($this->input->post('provinsi'))
		{
			$this->db->where('provinsi', $this->input->post('provinsi'));
		}
		if($this->input->post('id_paket'))
		{
			$this->db->like('id_paket', $this->input->post('id_paket'));
		}
		if($this->input->post('nama_zat_aktif'))
		{
			$this->db->like('nama_zat_aktif', $this->input->post('nama_zat_aktif'));
		}

		$this->db->from($this->table);
		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_POST['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	public function get_datatables()
	{
		$this->_get_datatables_query();
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		$query = $this->db->get();
		return $query->result();
	}

	public function count_filtered()
	{
		$this->_get_datatables_query();
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function count_all()
	{
		$this->db->from($this->table);
		return $this->db->count_all_results();
	}
	function provinsi()
	{
		$this->db->select('provinsi');
		$this->db->from('penawaran_import');
		$this->db->group_by('provinsi');
		$query = $this->db->get();
		$result = $query->result();
		$provinsis = array();
		foreach ($result as $row) 
		{
			$provinsis[] = $row->provinsi;
		}
		return $provinsis;
	}
	function  id_paket()
	{
		$this->db->select('id_paket');
		$this->db->from('penawaran_import');
		$this->db->group_by('id_paket');
		$query = $this->db->get();
		$result = $query->result();
		$id_pakets = array();
		foreach ($result as $row) 
		{
			$id_pakets[] = $row->id_paket;
		}
		return $id_pakets;
	}
	function  nama_zat_aktif()
	{
		$this->db->select('nama_zat_aktif');
		$this->db->from('penawaran_import');
		$this->db->group_by('nama_zat_aktif');
		$query = $this->db->get();
		$result = $query->result();
		$nama_zat_aktifs = array();
		foreach ($result as $row) 
		{
			$nama_zat_aktifs[] = $row->nama_zat_aktif;
		}
		return $nama_zat_aktifs;
	}
	public function get_by_id($id_paket,$provinsi)
	{
		$this->db->from($this->table);
		$this->db->where('id_paket',$id_paket);
		$this->db->where('provinsi',$provinsi);
		$query = $this->db->get();

		return $query->row();
	}
	public function update($where, $data)
	{
		$this->db->update($this->updateTable, $data, $where);
		return $this->db->affected_rows();
	}
	public function delete_by_id($id_paket , $provinsi)
	{
		$this->db->where('id_paket', $id_paket);
		$this->db->where('provinsi', $provinsi);
		$this->db->delete($this->updateTable);
	}





}