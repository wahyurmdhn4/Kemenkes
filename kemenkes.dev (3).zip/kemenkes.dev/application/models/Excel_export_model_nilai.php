<?php
class Excel_export_model_nilai extends CI_Model
{
 function fetch_data()
 {
  $this->db->order_by("id_paket", "DESC");
  $query = $this->db->get("vw_penilaian_paket");
  return $query->result();
 }

 
}
