<!-- start: Header -->
<nav class="navbar navbar-default header navbar-fixed-top">
          <div class="col-md-12 nav-wrapper">
            <div class="navbar-header" style="width:100%;">
              <div class="opener-left-menu is-open">
                <span class="top"></span>
                <span class="middle"></span>
                <span class="bottom"></span>
              </div>
                <a href="index.html" class="navbar-brand"> 
                 <b>APPS</b>
                </a>
              <ul class="nav navbar-nav navbar-right user-nav">
                <li class="user-name"><span>Admin</span></li>
                  <li class="dropdown avatar-dropdown">
                   <img src="<?php echo base_url('asset/img/avatar.jpg'); ?>" class="img-circle avatar" alt="user name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"/>
                   <ul class="dropdown-menu user-dropdown">
                     <li role="separator" class="divider"></li>
                     <li class="more">
                      <ul>
                        <li><a href=""><span class="fa fa-cogs"></span></a></li>
                        <li><a href=""><span class="fa fa-lock"></span></a></li>
                        <li><a href="<?php echo base_url('index.php/Auth/logout'); ?>"><span class="fa fa-power-off "></span></a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li ><a href="#" class="opener-right-menu"><span class="fa fa-coffee"></span></a></li>
              </ul>
            </div>
          </div>
        </nav>
      <!-- end: Header -->

      <div class="container-fluid mimin-wrapper">
  
          <!-- start:Left Menu -->
          <div id="left-menu">
              <div class="sub-left-menu scroll">
                <ul class="nav nav-list">
                    <li><div class="left-bg"></div></li>
                    <li class="time">
                      <h1 class="animated fadeInLeft">21:00</h1>
                      <p class="animated fadeInRight">Sat,October 1st 2029</p>
                    </li>
                    <li>
                      <a href="<?php echo base_url('index.php/admin/Dashboard');?>"><span class="fa-home fa"></span> Dashboard 
                      </a>
                      <li class="ripple"><a class="tree-toggle nav-header"><span class="fa fa-table"></span>Master Data<span class="fa-angle-right fa right-arrow text-right"></span> </a>
                      <ul class="nav nav-list tree">
                        <li><a href="<?php echo base_url('index.php/admin/Master_data'); ?>">Data Perpaket</a></li>
                        <li><a href="<?php echo base_url('index.php/admin/Master_data_all'); ?>">All Master Data</a></li>
                      </ul>
                    </li>
                    <li class="ripple"><a class="tree-toggle nav-header"><span class="fa fa-table"></span>Penawaran<span class="fa-angle-right fa right-arrow text-right"></span> </a>
                      <ul class="nav nav-list tree">
                        <li><a href="<?php echo base_url('index.php/admin/Lolos'); ?>">Lolos Evaluasi Harga</a></li>
                        <li><a href="<?php echo base_url('index.php/admin/Tidak_lolos'); ?>">Tidak Lolos</a></li>
                        <li><a href="<?php echo base_url('index.php/admin/Penawaran/gugur'); ?>">Gugur</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="<?php echo base_url('index.php/admin/Penilaian_paket');?>"><span class="fa fa-check"></span> Penilaian
                      </a>
                  </ul>
                </div>
            </div>
          <!-- end: Left Menu -->