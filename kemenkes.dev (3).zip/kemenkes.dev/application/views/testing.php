<html>
<head>
	<title>IMPORT EXCEL CI 3</title>
</head>

 <body id="mimin" class="dashboard">
 <?php $this->load->view('header'); ?>


	<h1>Data Testing</h1><hr>
	<button><a href="<?php echo base_url('index.php/admin/Testing/form'); ?>">Import Data</a><br><br></button>


	<table border="1" cellpadding="8">
	<tr>
		 <th>ID Paket</th>
         <th>Nama Industri</th>
         <th>Nama Zat Aktif</th>
         <th>Kemasan Syarat</th>
         <th>Kemasan Penawaran</th>
         <th>Komitmen Nasional PT</th>  
         <th>RKO Nasional </th>
         <th>Provinsi</th>
         <th>RKO Provinsi</th>
         <th>HPS Provinsi</th>
         <th>Harga Penawaran</th>
	</tr>

	<?php
	if( ! empty($penawaran_import)){ // Jika data pada database tidak sama dengan empty (alias ada datanya)
		foreach($penawaran_import as $data){ // Lakukan looping pada variabel siswa dari controller
			echo "<tr>";
			echo "<td>".$data->id_paket."</td>";
			echo "<td>".$data->nama_industri."</td>";
			echo "<td>".$data->nama_zat_aktif."</td>";
			echo "<td>".$data->kemasan_syarat."</td>";
			echo "<td>".$data->kemasan_penawaran."</td>";
			echo "<td>".$data->komitmen_nasional_pt."</td>";
			echo "<td>".$data->rko_nasional."</td>";
			echo "<td>".$data->provinsi."</td>";
			echo "<td>".$data->rko_prov."</td>";
			echo "<td>".$data->hps_provinsi."</td>";
			echo "<td>".$data->harga_penawaran."</td>";
			echo "</tr>";
		}
	}else{ // Jika data tidak ada
		echo "<tr><td colspan='4'>Data tidak ada</td></tr>";
	}
	?>
	</table>
</body>
</html>
