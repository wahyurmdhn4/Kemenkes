<html>
<head>
	<title>Form Import</title>

	<!-- Load File jquery.min.js yang ada difolder js -->
	<script src="<?php echo base_url('js/jquery.min.js'); ?>"></script>

	<script>
	$(document).ready(function(){
		// Sembunyikan alert validasi kosong
		$("#kosong").hide();
	});
	</script>
</head>
<body>
	<h3>Form Import</h3>
	<hr>

	<a href="<?php echo base_url("excel/format.xlsx"); ?>">Download Format</a>
	<br>
	<br>

	<!-- Buat sebuah tag form dan arahkan action nya ke controller ini lagi -->
	<form method="post" action="<?php echo base_url('index.php/admin/Testing/form'); ?>" enctype="multipart/form-data">
		<!--
		-- Buat sebuah input type file
		-- class pull-left berfungsi agar file input berada di sebelah kiri
		-->
		<input type="file" name="file">

		<!--
		-- BUat sebuah tombol submit untuk melakukan preview terlebih dahulu data yang akan di import
		-->
		<input type="submit" name="preview" value="Preview">
	</form>

	<script>
        $(document).ready(function(){

          $('#import_form').on('submit', function(event){
            event.preventDefault();
            $.ajax({
              url:"<?php echo base_url();?>index.php/admin/Testing/import",
              method:"POST",
              data:new FormData(this),
              contentType:false,
              cache:false,
              processData:false,
              success:function(data){
                $('#file').val('');
                alert(data);
              }
            })
          });

        });
    </script>
     

	<?php
	if(isset($_POST['preview'])){ // Jika user menekan tombol Preview pada form
		if(isset($upload_error)){ // Jika proses upload gagal
			echo "<div style='color: red;'>".$upload_error."</div>"; // Muncul pesan error upload
			die; // stop skrip
		}

		// Buat sebuah tag form untuk proses import data ke database
		echo "<form method='post' action='".base_url("index.php/admin/Testing/import")."'>";


		// Buat sebuah div untuk alert validasi kosong
		echo "<div style='color: red;' id='kosong'>
		Semua data belum diisi, Ada <span id='jumlah_kosong'></span> data yang belum diisi.
		</div>";

		echo "<table border='1' cellpadding='8'>
		<tr>
			<th colspan='5'>Preview Data</th>
		</tr>
		<tr>
			<th>ID Paket</th>
                          <th>Nama Industri</th>
                          <th>Nama Zat Aktif</th>
                          <th>Kemasan Syarat</th>
                          <th>Kemasan Penawaran</th>
                          <th>Komitmen Nasional PT</th>  
                          <th>RKO Nasional </th>
                          <th>Provinsi</th>
                          <th>RKO Provinsi</th>
                          <th>HPS Provinsi</th>
                          <th>Harga Penawaran</th>
		</tr>";

		$numrow = 2;
		$kosong = 0;

		// Lakukan perulangan dari data yang ada di excel
		// $sheet adalah variabel yang dikirim dari controller
		foreach($sheet as $row){
			// Ambil data pada excel sesuai Kolom
			$id_paket = $row['A']; // Ambil data NIS
      $nama_industri = $row['B']; // Ambil data nama
      $nama_zat_aktif = $row['C']; // Ambil data jenis kelamin
      $kemasan_syarat = $row['D'];
      $kemasan_penawaran = $row['E'];
      $komitmen_nasional_pt = $row['F'];
      $rko_nasional = $row['G'];
      $provinsi = $row['H'];
      $rko_prov = $row['I'];
      $hps_provinsi = $row['J'];
      $harga_penawaran = $row['K']; // Ambil data alamat

			// Cek jika semua data tidak diisi
			if($id_paket == "" && $nama_industri == "" && $nama_zat_aktif == "" && $kemasan_syarat == "" && $kemasan_penawaran == "" && $komitmen_nasional_pt == "" && $rko_nasional == "" && $provinsi == "" && $rko_prov == "" && $hps_provinsi == "" && $harga_penawaran == "")
        continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)

			// Cek $numrow apakah lebih dari 1
			// Artinya karena baris pertama adalah nama-nama kolom
			// Jadi dilewat saja, tidak usah diimport
			if($numrow > 3){
				// Validasi apakah semua data telah diisi
				$id_paket_td = ( ! empty($id_paket))? "" : " style='background: #E07171;'"; // Jika NIS kosong, beri warna merah
        $nama_industri_td = ( ! empty($nama_industri))? "" : " style='background: #E07171;'"; // Jika Nama kosong, beri warna merah
        $nama_zat_aktif_td = ( ! empty($nama_zat_aktif))? "" : " style='background: #E07171;'"; // Jika Jenis Kelamin kosong, beri warna merah
        $kemasan_syarat_td = ( ! empty($kemasan_syarat))? "" : " style='background: #E07171;'"; // Jika Alamat kosong, beri warna merah
        $kemasan_penawaran_td = ( ! empty($kemasan_penawaran))? "" : " style='background: #E07171;'";
        $komitmen_nasional_pt_td = ( ! empty($komitmen_nasional_pt))? "" : " style='background: #E07171;'";
        $rko_nasional_td = ( ! empty($rko_nasional))? "" : " style='background: #E07171;'";
        $provinsi_td = ( ! empty($provinsi))? "" : " style='background: #E07171;'";
        $rko_prov_td = ( ! empty($rko_prov))? "" : " style='background: #E07171;'";
        $hps_provinsi_td = ( ! empty($hps_provinsi))? "" : " style='background: #E07171;'";
        $harga_penawaran_td = ( ! empty($harga_penawaran))? "" : " style='background: #E07171;'"; // Jika Alamat kosong, beri warna merah

				// Jika salah satu data ada yang kosong
				if($id_paket == "" or $nama_industri == "" or $nama_zat_aktif == "" or $kemasan_syarat == "" or $kemasan_penawaran == "" or $komitmen_nasional_pt == "" or $rko_nasional == "" or $provinsi == "" or $rko_prov == "" or $hps_provinsi == "" or $harga_penawaran == ""){
          $kosong++; // Tambah 1 variabel $kosong
				}

				echo "<tr>";
        echo "<td".$id_paket_td.">".$id_paket."</td>";
        echo "<td".$nama_industri_td.">".$nama_industri."</td>";
        echo "<td".$nama_zat_aktif_td.">".$nama_zat_aktif."</td>";
        echo "<td".$kemasan_syarat_td.">".$kemasan_syarat."</td>";
        echo "<td".$kemasan_penawaran_td.">".$kemasan_penawaran."</td>";
        echo "<td".$komitmen_nasional_pt_td.">".$komitmen_nasional_pt."</td>";
        echo "<td".$rko_nasional_td.">".$rko_nasional."</td>";
        echo "<td".$provinsi_td.">".$provinsi."</td>";
        echo "<td".$rko_prov_td.">".$rko_prov."</td>";
        echo "<td".$hps_provinsi_td.">".$hps_provinsi."</td>";
        echo "<td".$harga_penawaran_td.">".$harga_penawaran."</td>";
        echo "</tr>";
			}

			$numrow++; // Tambah 1 setiap kali looping
		}

		echo "</table>";


		// Cek apakah variabel kosong lebih dari 0
		// Jika lebih dari 0, berarti ada data yang masih kosong
		if($kosong > 0){
		?>
			<script>
			$(document).ready(function(){
				// Ubah isi dari tag span dengan id jumlah_kosong dengan isi dari variabel kosong
				$("#jumlah_kosong").html('<?php echo $kosong; ?>');

				$("#kosong").show(); // Munculkan alert validasi kosong
			});
			</script>
		<?php
		}else{ // Jika semua data sudah diisi
			echo "<hr>";

			// Buat sebuah tombol untuk mengimport data ke database
			echo "<button type='submit' name='import'>Import</button>";
			echo "<a href='".base_url("index.php/admin/Testing")."'>Cancel</a>";
		}

		echo "</form>";
	}
	?>


</body>
</html>
