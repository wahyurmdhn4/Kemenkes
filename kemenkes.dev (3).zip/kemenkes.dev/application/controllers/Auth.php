<?php
	class Auth extends CI_Controller {

		function __construct(){
			parent::__construct();
			
			$this->load->model('Model_Auth');
		}

		public function index(){
			if($this->session->userdata('logged_in') == true){
				switch($this->session->userdata('level')){
					case 1 :
						redirect(site_url('admin/Dashboard'));
						//echo 'move to ' . site_url('index.php/a/Rekap/RekapNasional/provinsi');
						break;
					case 2 :
						redirect(site_url('d/Dashboard/PIP2017'));
						//echo 'move to ' . site_url('index.php/d/Dashboard');
						break;
					case 3 :
						redirect(site_url('sa/Dashboard/LayakPIP/provinsi'));
						//echo 'move to ' . site_url('index.php/d/Dashboard');
						break;
					case 10 :
						redirect(site_url('skl/Dashboard/PIP2017'));
						//echo 'move to ' . site_url('index.php/d/Dashboard');
						break;
				}
			}else{
				$this->load->view('login');
			}
		}

		public function login(){
			$username = $this->input->post('username', 'true');
			$password = $this->input->post('password', 'true');

			$login_status = $this->Model_Auth->login($username, $password)->row(); 

			$num_account = count($login_status);

			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('notification', 'Peringatan : Username dan Password tidak cocok');
				redirect(site_url('Auth'));
			}else{
				if ($num_account > 0){

					$array_items = array(
						'id_user'				=> $login_status->id_user,
						'username'				=> $login_status->username,
						'level'					=> $login_status->level,
						'nama'					=> $login_status->nama,
						'logged_in'				=> true
					);
					
					$this->session->set_userdata($array_items);
					redirect(site_url('Auth'));

				}else{
					$this->session->set_flashdata('notification', 'Peringatan : Username dan Password tidak cocok');
					redirect(site_url('Auth'));
				}
			}
		}

		function logout(){
			$array_items = array(
				'id_user'				=> '',
				'username'				=> '',
				'level'				=> '',
				'nama'					=> '',
				'logged_in'				=> false
			);

			$this->session->set_userdata($array_items);
			$this->session->unset_userdata($array_items);

			$this->session->sess_destroy();
			
			redirect(site_url('Auth'));
		}

		function LogSekolah(){
			$this->load->view('login_sekolah');
		}

	}
?>