<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penilaian_detail extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Model_penilaian_detail');
	}
	function check_still_active(){
		if(!$this->session->userdata('logged_in')){
			redirect(site_url('Auth'));
		}
	}
	public function index()
	{
        $data['id_paket'] =  $this->uri->segment(3);
		$provinsis = $this->Model_penilaian_detail->provinsi();
        $opt = array('' => 'All Country');
        foreach ($provinsis as $provinsi) {
			$opt[$provinsi] = $provinsi;
		}

		$data['form_provinsi'] = form_dropdown('',$opt,'','id="provinsi" class="form-control"');

		$id_pakets = $this->Model_penilaian_detail->id_paket();
        $opt = array('' => 'Semua Paket');
        foreach ($id_pakets as $id_paket) {
			$opt[$id_paket] = $id_paket;
		}

		$data['form_id_paket'] = form_dropdown('',$opt,'','id="id_paket" class="form-control"');
		$nama_zat_aktifs = $this->Model_penilaian_detail->nama_zat_aktif();
        $opt = array('' => 'Semua Jenis');
        foreach ($nama_zat_aktifs as $nama_zat_aktif) {
			$opt[$nama_zat_aktif] = $nama_zat_aktif;
		}

		$data['form_nama_zat_aktif'] = form_dropdown('',$opt,'','id="nama_zat_aktif" class="form-control"');
		$this->load->view('penilaian_detail',$data,false);
		$this->check_still_active();
    }
    public function detail()
	{
        $data['id_paket'] =  urldecode($this->uri->segment(4));
        $data['provinsi'] =  urldecode($this->uri->segment(5));
        $data['nama_zat_aktif'] =  urldecode($this->uri->segment(6));
		$provinsis = $this->Model_penilaian_detail->provinsi();
        $opt = array('' => 'All Country');
        foreach ($provinsis as $provinsi) {
			$opt[$provinsi] = $provinsi;
		}

		$data['form_provinsi'] = form_dropdown('',$opt,'','id="provinsi" class="form-control"');

		$id_pakets = $this->Model_penilaian_detail->id_paket();
        $opt = array('' => 'Semua Paket');
        foreach ($id_pakets as $id_paket) {
			$opt[$id_paket] = $id_paket;
		}

		$data['form_id_paket'] = form_dropdown('',$opt,'','id="id_paket" class="form-control"');
		$nama_zat_aktifs = $this->Model_penilaian_detail->nama_zat_aktif();
        $opt = array('' => 'Semua Jenis');
        foreach ($nama_zat_aktifs as $nama_zat_aktif) {
			$opt[$nama_zat_aktif] = $nama_zat_aktif;
		}

		$data['form_nama_zat_aktif'] = form_dropdown('',$opt,'','id="nama_zat_aktif" class="form-control"');
		$this->load->view('penilaian_detail',$data,false);
		$this->check_still_active();
	}
	public function ajax_list()
	{
        
        $id_paket = urldecode($this->uri->segment(4));
        $provinsi = urldecode($this->uri->segment(5));
        $nama_zat_aktif = urldecode($this->uri->segment(6));
		$list = $this->Model_penilaian_detail->get_datatables($id_paket,$provinsi ,$nama_zat_aktif);
		$data = array();
		foreach ($list as $rows) {
			if($rows->dimenangkan != null){
				$disabled  = '<button type="button" class="btn btn-danger disabled">Sudah</button>';
			}else 
			{
				if($rows->sisa_komitmen < $rows->rko_prov)
				{
					$disabled  = '<button type="button" class="btn btn-danger disabled">Tidak Memenuhi</button>';
				}else{
					$disabled = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="add_pemenang('."'".$rows->id_import."'".')" ><i class="glyphicon glyphicon-pencil"></i> Menangkan</a>';
				}	
	
			}
			if($rows->status == 'Kalah Kualifikasi'){
				$warna = 'danger';
			}else if($rows->status == 'Belum ada pemenang'){
				$warna =  'default';
				
			}else{
				$warna = 'success';
			}
			$row = array();
            $row[] = $rows->rangking;
            $row[] = $rows->nama_industri;
			$row[] = $rows->nama_zat_aktif;
            $row[] = $rows->kemasan_penawaran;
            $row[] = number_format($rows->komitmen_nasional_pt);  
			$row[] = number_format($rows->rko_prov);
            $row[] = $rows->hps_provinsi;
            $row[] = $rows->harga_penawaran;
            $row[] = '<span class="text-'.$warna.' text-center">'.$rows->status.'</span>';
            $row[] = $rows->sisa_komitmen;
			$row[] = $disabled;


			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->Model_penilaian_detail->count_all(),
						"recordsFiltered" => $this->Model_penilaian_detail->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
	public function ajax_edit($id_import)
	{
		$data = $this->Model_penilaian_detail->get_by_id($id_import);
		echo json_encode($data);
	}
	public function ajax_update()
	{
		$data = array(
				'id_import' => $this->input->post('id_import'),
				'rko_prov' => $this->input->post('rko_prov'),
				'harga_penawaran' => $this->input->post('harga_penawaran'),
				'nama_industri' => $this->input->post('nama_industri'),
				'nama_zat_aktif' => $this->input->post('nama_zat_aktif'),
				'id_paket' => $this->input->post('id_paket'),
				'provinsi' => $this->input->post('provinsi'),
			);
		$this->Model_penilaian_detail->pemenang($data);
		$this->Model_penilaian_detail->update_status();
		echo json_encode(array("status" => TRUE));
	}
	public function ajax_delete($id_import)
	{
		$this->Model_penilaian_detail->delete_by_id($id_import);
		echo json_encode(array("status" => TRUE));
	}
	

}
