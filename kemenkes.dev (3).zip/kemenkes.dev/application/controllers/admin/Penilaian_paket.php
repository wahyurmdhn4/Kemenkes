<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penilaian_paket extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Model_penilaian_paket');
	}
	function check_still_active(){
		if(!$this->session->userdata('logged_in')){
			redirect(site_url('Auth'));
		}
	}
	public function index()
	{
		$provinsis = $this->Model_penilaian_paket->provinsi();
        $opt = array('' => 'All Country');
        foreach ($provinsis as $provinsi) {
			$opt[$provinsi] = $provinsi;
		}

		$data['form_provinsi'] = form_dropdown('',$opt,'','id="provinsi" class="form-control"');

		$id_pakets = $this->Model_penilaian_paket->id_paket();
        $opt = array('' => 'Semua Paket');
        foreach ($id_pakets as $id_paket) {
			$opt[$id_paket] = $id_paket;
		}

		$data['form_id_paket'] = form_dropdown('',$opt,'','id="id_paket" class="form-control"');
		$nama_zat_aktifs = $this->Model_penilaian_paket->nama_zat_aktif();
        $opt = array('' => 'Semua Jenis');
        foreach ($nama_zat_aktifs as $nama_zat_aktif) {
			$opt[$nama_zat_aktif] = $nama_zat_aktif;
		}

		$data['form_nama_zat_aktif'] = form_dropdown('',$opt,'','id="nama_zat_aktif" class="form-control"');
		$this->load->view('penilaian_paket',$data,false);
		$this->check_still_active();
	}
	public function ajax_list()
	{

		$list = $this->Model_penilaian_paket->get_datatables();
		$data = array();
		
		foreach ($list as $rows) {
			if($rows->status == 'Belum Ada Pemenang'){
				$button = '<a class="btn btn-primary" href="Penilaian_detail/detail/'.$rows->id_paket.'/'.$rows->provinsi.'/'.$rows->nama_zat_aktif.'/" role="button">Pilih Pemenang</a>';
				$warna = 'default';
	
			}else{
				$button = '<button type="button" class="btn btn-danger disabled">Sudah Ada Pemenang</button>';
				$warna = 'success';
			}
            $row = array();
			$row[] = $rows->id_paket;
			$row[] = $rows->nama_zat_aktif;
			$row[] = $rows->kemasan_syarat;
			$row[] = number_format($rows->rko_nasional);
			$row[] = $rows->provinsi;
			$row[] = number_format($rows->rko_prov);
			$row[] = $rows->hps_provinsi;
			$row[] = '<span class="text-'.$warna.' text-center">'.$rows->status.'</span>'; 
            $row[] = $button;


			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->Model_penilaian_paket->count_all(),
						"recordsFiltered" => $this->Model_penilaian_paket->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
	public function ajax_edit($id_paket,$provinsi)
	{
		$data = $this->Model_penilaian_paket->get_by_id($id_paket,$provinsi);
		echo json_encode($data);
	}
	public function ajax_update()
	{
		$data = array(
				'nama_zat_aktif' => $this->input->post('nama_zat_aktif'),
				'kemasan_syarat' => $this->input->post('kemasan_syarat'),
				'hps_provinsi' => $this->input->post('hps_provinsi'),
			);
		$this->Model_penilaian_paket->update(array('id_paket' => $this->input->post('id_paket'),'provinsi' => $this->input->post('provinsi')), $data);
		echo json_encode(array("status" => TRUE));
	}
	public function ajax_delete($id_paket,$provinsi)
	{
		$this->Model_penilaian_paket->delete_by_id($id_paket,$provinsi);
		echo json_encode(array("status" => TRUE));
	}

}
