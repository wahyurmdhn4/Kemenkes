<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_data_all extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Model_master_data_all');
	}
	function check_still_active(){
		if(!$this->session->userdata('logged_in')){
			redirect(site_url('Auth'));
		}
	}
	public function index()
	{
		$provinsis = $this->Model_master_data_all->provinsi();
        $opt = array('' => 'All Country');
        foreach ($provinsis as $provinsi) {
			$opt[$provinsi] = $provinsi;
		}

		$data['form_provinsi'] = form_dropdown('',$opt,'','id="provinsi" class="form-control"');

		$id_pakets = $this->Model_master_data_all->id_paket();
        $opt = array('' => 'Semua Paket');
        foreach ($id_pakets as $id_paket) {
			$opt[$id_paket] = $id_paket;
		}

		$data['form_id_paket'] = form_dropdown('',$opt,'','id="id_paket" class="form-control"');
		$nama_zat_aktifs = $this->Model_master_data_all->nama_zat_aktif();
        $opt = array('' => 'Semua Jenis');
        foreach ($nama_zat_aktifs as $nama_zat_aktif) {
			$opt[$nama_zat_aktif] = $nama_zat_aktif;
		}

		$data['form_nama_zat_aktif'] = form_dropdown('',$opt,'','id="nama_zat_aktif" class="form-control"');
		$this->load->view('master_data_all',$data,false);
		$this->check_still_active();
	}
	public function ajax_list()
	{
		$list = $this->Model_master_data_all->get_datatables();
		$data = array();
		foreach ($list as $rows) {
			$row = array();
            $row[] = $rows->id_paket;
            $row[] = $rows->nama_industri;
			$row[] = $rows->nama_zat_aktif;
            $row[] = $rows->kemasan_syarat;
            $row[] = $rows->kemasan_penawaran;
            $row[] = number_format($rows->komitmen_nasional_pt);            
			$row[] = number_format($rows->rko_nasional);
			$row[] = $rows->provinsi;
			$row[] = number_format($rows->rko_prov);
            $row[] = $rows->hps_provinsi;
            $row[] = $rows->harga_penawaran;
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_data('."'".$rows->id_import."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
			<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_data('."'".$rows->id_import."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';


			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->Model_master_data_all->count_all(),
						"recordsFiltered" => $this->Model_master_data_all->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
	public function ajax_edit($id_import)
	{
		$data = $this->Model_master_data_all->get_by_id($id_import);
		echo json_encode($data);
	}
	public function ajax_update()
	{
		$data = array(
				'nama_zat_aktif' => $this->input->post('nama_zat_aktif'),
				'kemasan_syarat' => $this->input->post('kemasan_syarat'),
				'harga_penawaran' => $this->input->post('harga_penawaran'),
				'komitmen_nasional_pt' => $this->input->post('komitmen_nasional_pt'),
			);
		$this->Model_master_data_all->update(array('id_import' => $this->input->post('id_import')), $data);
		echo json_encode(array("status" => TRUE));
	}
	public function ajax_delete($id_import)
	{
		$this->Model_master_data_all->delete_by_id($id_import);
		echo json_encode(array("status" => TRUE));
	}

}
