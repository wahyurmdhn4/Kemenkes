<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penawaran extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Model_master_data');
	}
	function check_still_active(){
		if(!$this->session->userdata('logged_in')){
			redirect(site_url('Auth'));
		}
	}
	public function index()
	{
        $data['data'] = $this->Model_master_data->all();
		$this->load->view('lolos',$data);
		$this->check_still_active();
    }
    
    function tidak_lolos(){
        $data['tidak_lolos'] = $this->Model_master_data->tidak_lolos();
        $this->load->view('tidak_lolos',$data);
        $this->check_still_active();
    }
    function gugur(){
        $data['gugur'] = $this->Model_master_data->gugur();
        $this->load->view('gugur',$data);
        $this->check_still_active();
    }
    function penilaian(){
        $data['penilaian'] = $this->Model_master_data->penilaian_pilih();
        $provinsis = $this->Model_master_data->provinsi();
        $opt = array('' => 'All Country');
        foreach ($provinsis as $provinsi) {
			$opt[$provinsi] = $provinsi;
		}

		$data['form_provinsi'] = form_dropdown('',$opt,'','id="provinsi" class="form-control"');
        $this->load->view('penilaian',$data);
        $this->check_still_active();
    }

    function penilaian_detail(){
        $provinsi = $this->uri->segment(4);
        $id_paket = $this->uri->segment(5);
        $data['penilaian_detail'] = $this->Model_master_data->penilaian_detail($provinsi , $id_paket);
        $this->load->view('penilaian_detail',$data);
        $this->check_still_active();
    }
    public function ajax_list()
	{
		$list = $this->Model_master_data->penilaian_pilih();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $rows) {
			$row[] = $rows->id_paket;
			$row[] = $rows->nama_zat_aktif;
			$row[] = number_format($row->rko_nasional);
			$row[] = $rows->provinsi;
			$row[] = number_format($row->rko_prov);
			$row[] = $rows->hps_provinsi;

			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->customers->count_all(),
						"recordsFiltered" => $this->customers->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}


}
