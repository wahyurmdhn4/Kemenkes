<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	private $filename = "import_data";
	function __construct(){
		parent::__construct();
		$this->load->model('excel_import_model');
		/*$this->load->library('excel');*/
	}
	function check_still_active(){
		if(!$this->session->userdata('logged_in')){
			redirect(site_url('Auth'));
		}
	}
	public function index()
	{
		
		/*$data['penawaran_import'] = $this->excel_import_model->view();*/
		$data['penawaran_import'] = $this->excel_import_model->view();
		$this->load->view('dashboard',$data);
		$this->check_still_active();
	}
	function form()
	{
		$data = array();

		if(isset($_POST['preview'])){ // Jika user menekan tombol Preview pada form
      // lakukan upload file dengan memanggil function upload yang ada di SiswaModel.php
      $upload = $this->excel_import_model->upload_file($this->filename);
      
      if($upload['result'] == "success"){ // Jika proses upload sukses
        // Load plugin PHPExcel nya
        // include APPPATH.'libraries/PHPExcel/PHPExcel.php';
        
        $excelreader = new PHPExcel_Reader_Excel2007();
        $loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx'); // Load file yang tadi diupload ke folder excel
        $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
        
        // Masukan variabel $sheet ke dalam array data yang nantinya akan di kirim ke file form.php
        // Variabel $sheet tersebut berisi data-data yang sudah diinput di dalam excel yang sudha di upload sebelumnya
        $data['sheet'] = $sheet; 
      }else{ // Jika proses upload gagal
        $data['upload_error'] = $upload['error']; // Ambil pesan error uploadnya untuk dikirim ke file form dan ditampilkan
      }
    }
    
    $this->load->view('dashboard', $data);

	}
	function import()
	{
	include APPPATH.'libraries/PHPExcel.php';
    
/*    $excelreader = new PHPExcel_Reader_Excel2007();
    $loadexcel = $excelreader->load('excel/'.$this->filename.'.xlsx'); // Load file yang telah diupload ke folder excel
    $sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);
    
    // Buat sebuah variabel array untuk menampung array data yg akan kita insert ke database
    $data = array();
    
    $numrow = 2;
    foreach($sheet as $row){
      // Cek $numrow apakah lebih dari 1
      // Artinya karena baris pertama adalah nama-nama kolom
      // Jadi dilewat saja, tidak usah diimport
      if($numrow > 2){
        // Kita push (add) array data ke variabel data
        array_push($data, array(
          'id_paket'=>$row['A'], // Insert data nis dari kolom A di excel
          'nama_industri'=>$row['B'], // Insert data nama dari kolom B di excel
          'nama_zat_aktif'=>$row['C'], // Insert data jenis kelamin dari kolom C di excel
          'kemasan_syarat'=>$row['D'],
          'kemasan_penawaran'=>$row['E'],
          'komitmen_nasional_pt'=>$row['F'],
          'rko_nasional'=>$row['G'],
          'provinsi'=>$row['H'],
          'rko_prov'=>$row['I'],
          'hps_provinsi'=>$row['J'], // Insert data alamat dari kolom D di excel
          'harga_penawaran'=>$row['K'],
        ));
      }
      
      $numrow++; // Tambah 1 setiap kali looping
    }
    // Panggil fungsi insert_multiple yg telah kita buat sebelumnya di model
    $this->excel_import_model->insert_batch($data);*/
    
    /*redirect("Dashboard");*/
		if(isset($_FILES["file"]["name"]))
		{
			$path = $_FILES["file"]["tmp_name"];
			$object = PHPExcel_IOFactory::load($path);
			foreach($object->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
				for($row=3; $row<=$highestRow; $row++)
				{
					$id_paket = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$nama_industri = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
					$nama_zat_aktif = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
					$kemasan_syarat = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
					$kemasan_penawaran = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
					$komitmen_nasional_pt = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
					$rko_nasional = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
					$provinsi = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
					$rko_prov = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
					$hps_prov = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
					$harga_penawaran = $worksheet->getCellByColumnAndRow(10, $row)->getValue();

					$data[] = array(
						'id_paket'		=>	$id_paket,
						'nama_industri'			=>	$nama_industri,
						'nama_zat_aktif'				=>	$nama_zat_aktif,
						'kemasan_syarat'		=>	$kemasan_syarat,
						'kemasan_penawaran'			=>	$kemasan_penawaran,
						'komitmen_nasional_pt'		=>	$komitmen_nasional_pt,
						'rko_nasional'			=>	$rko_nasional,
						'provinsi'				=>	$provinsi,
						'rko_prov'		=>	$rko_prov,
						'hps_provinsi'			=>	$hps_prov,
						'harga_penawaran'			=>	$harga_penawaran
					);
				}
			}
			
				$this->excel_import_model->insert($data);
				echo "suskes";
			
		}	
	}

}
