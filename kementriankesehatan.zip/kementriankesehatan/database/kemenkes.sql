-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2019 at 09:43 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kemenkes`
--

-- --------------------------------------------------------

--
-- Table structure for table `download`
--

CREATE TABLE `download` (
  `id` int(11) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `nama_file` varchar(100) NOT NULL,
  `jenis_file` varchar(100) NOT NULL,
  `tipe_file` varchar(10) NOT NULL,
  `ukuran_file` varchar(100) NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `download`
--

INSERT INTO `download` (`id`, `tanggal_upload`, `nama_file`, `jenis_file`, `tipe_file`, `ukuran_file`, `file`) VALUES
(71, '2019-08-22', 'apg akbar 001.jpg', 'FOTOEvent', 'jpg', '3619166', 'files/apg akbar 001.jpg.jpg'),
(72, '2019-08-22', 'milktea.jpg', 'FOTOTraining', 'jpg', '6360', 'files/milktea.jpg.jpg'),
(73, '2019-08-22', 'estea.jpg', 'FOTOTraining', 'jpg', '4596', 'files/estea.jpg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(5) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password`, `nama_lengkap`, `email`, `jenis_kelamin`, `level`) VALUES
(1, 'admin001', '2748a4cb2e93d34935362b71fd80ac26', 'Rifki Abdillah', 'rifkiabdillah2015@gmail.com', 'Pria', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kemenkes`
--

CREATE TABLE `tb_kemenkes` (
  `kode_obat` varchar(100) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `kemasan_dipersyaratkan` varchar(100) NOT NULL,
  `industri_farmasi` varchar(100) NOT NULL,
  `komitmen_nasional` varchar(100) NOT NULL,
  `rko_nasional` varchar(100) NOT NULL,
  `rko_lampung` varchar(100) NOT NULL,
  `hps_lampung` varchar(100) NOT NULL,
  `harga_lampung` varchar(100) NOT NULL,
  `rko_banten` varchar(100) NOT NULL,
  `hps_banten` varchar(100) NOT NULL,
  `harga_banten` varchar(100) NOT NULL,
  `rko_jakarta` varchar(100) NOT NULL,
  `hps_jakarta` varchar(100) NOT NULL,
  `harga_jakarta` varchar(100) NOT NULL,
  `rko_jawabarat` varchar(100) NOT NULL,
  `hps_jawabarat` varchar(100) NOT NULL,
  `harga_jawabarat` varchar(100) NOT NULL,
  `rko_jawatengah` varchar(100) NOT NULL,
  `hps_jawatengah` varchar(100) NOT NULL,
  `harga_jawatengah` varchar(100) NOT NULL,
  `rko_yogyakarta` varchar(100) NOT NULL,
  `hps_yogyakarta` varchar(100) NOT NULL,
  `harga_yogyakarta` varchar(100) NOT NULL,
  `rko_jawatimur` varchar(100) NOT NULL,
  `hps_jawatimur` varchar(100) NOT NULL,
  `harga_jawatimur` varchar(100) NOT NULL,
  `rko_bali` varchar(100) NOT NULL,
  `hps_bali` varchar(100) NOT NULL,
  `harga_bali` varchar(100) NOT NULL,
  `rko_sumaterautara` varchar(100) NOT NULL,
  `hps_sumaterautara` varchar(100) NOT NULL,
  `harga_sumaterautara` varchar(100) NOT NULL,
  `rko_sumaterabarat` varchar(100) NOT NULL,
  `hps_sumaterabarat` varchar(100) NOT NULL,
  `harga_sumaterabarat` varchar(100) NOT NULL,
  `rko_riau` varchar(100) NOT NULL,
  `hps_riau` varchar(100) NOT NULL,
  `harga_riau` varchar(100) NOT NULL,
  `rko_jambi` varchar(100) NOT NULL,
  `hps_jambi` varchar(100) NOT NULL,
  `harga_jambi` varchar(100) NOT NULL,
  `rko_sumateraselatan` varchar(100) NOT NULL,
  `hps_sumateraselatan` varchar(100) NOT NULL,
  `harga_sumateraselatan` varchar(100) NOT NULL,
  `rko_bengkulu` varchar(100) NOT NULL,
  `hps_bengkulu` varchar(100) NOT NULL,
  `harga_bengkulu` varchar(100) NOT NULL,
  `rko_kepulauanbangkabelitung` varchar(100) NOT NULL,
  `hps_kepulauanbangkabelitung` varchar(100) NOT NULL,
  `harga_kepulauanbangkabelitung` varchar(100) NOT NULL,
  `rko_nusatenggarabarat` varchar(100) NOT NULL,
  `hps_nusatenggarabarat` varchar(100) NOT NULL,
  `harga_nusatenggarabarat` varchar(100) NOT NULL,
  `rko_kepulauanriau` varchar(100) NOT NULL,
  `hps_kepulauanriau` varchar(100) NOT NULL,
  `harga_kepulauanriau` varchar(100) NOT NULL,
  `rko_aceh` varchar(100) NOT NULL,
  `hps_aceh` varchar(100) NOT NULL,
  `harga_aceh` varchar(100) NOT NULL,
  `rko_kalimantanbarat` varchar(100) NOT NULL,
  `hps_kalimantanbarat` varchar(100) NOT NULL,
  `harga_kalimantanbarat` varchar(100) NOT NULL,
  `rko_kalimantanselatan` varchar(100) NOT NULL,
  `hps_kalimantanselatan` varchar(100) NOT NULL,
  `harga_kalimantanselatan` varchar(100) NOT NULL,
  `rko_kalimantantimur` varchar(100) NOT NULL,
  `hps_kalimantantimur` varchar(100) NOT NULL,
  `harga_kalimantantimur` varchar(100) NOT NULL,
  `rko_sulawesiutara` varchar(100) NOT NULL,
  `hps_sulawesiutara` varchar(100) NOT NULL,
  `harga_sulawesiutara` varchar(100) NOT NULL,
  `rko_sulawesitengah` varchar(100) NOT NULL,
  `hps_sulawesitengah` varchar(100) NOT NULL,
  `harga_sulawesitengah` varchar(100) NOT NULL,
  `rko_sulawesiselatan` varchar(100) NOT NULL,
  `hps_sulawesiselatan` varchar(100) NOT NULL,
  `harga_sulawesiselatan` varchar(100) NOT NULL,
  `rko_kalimantanutara` varchar(100) NOT NULL,
  `hps_kalimantanutara` varchar(100) NOT NULL,
  `harga_kalimantanutara` varchar(100) NOT NULL,
  `rko_kalimantantengah` varchar(100) NOT NULL,
  `hps_kalimantantengah` varchar(100) NOT NULL,
  `harga_kalimantantengah` varchar(100) NOT NULL,
  `rko_sulawesitenggara` varchar(100) NOT NULL,
  `hps_sulawesitenggara` varchar(100) NOT NULL,
  `harga_sulawesitenggara` varchar(100) NOT NULL,
  `rko_gorontalo` varchar(100) NOT NULL,
  `hps_gorontalo` varchar(100) NOT NULL,
  `harga_gorontalo` varchar(100) NOT NULL,
  `rko_sulawesibarat` varchar(100) NOT NULL,
  `hps_sulawesibarat` varchar(100) NOT NULL,
  `harga_sulawesibarat` varchar(100) NOT NULL,
  `rko_nusatenggaratimur` varchar(100) NOT NULL,
  `hps_nusatenggaratimur` varchar(100) NOT NULL,
  `harga_nusatenggaratimur` varchar(100) NOT NULL,
  `rko_maluku` varchar(100) NOT NULL,
  `hps_maluku` varchar(100) NOT NULL,
  `harga_maluku` varchar(100) NOT NULL,
  `rko_malukuutara` varchar(100) NOT NULL,
  `hps_malukuutara` varchar(100) NOT NULL,
  `harga_malukuutara` varchar(100) NOT NULL,
  `rko_papuabarat` varchar(100) NOT NULL,
  `hps_papuabarat` varchar(100) NOT NULL,
  `harga_papuabarat` varchar(100) NOT NULL,
  `rko_papua` varchar(100) NOT NULL,
  `hps_papua` varchar(100) NOT NULL,
  `harga_papua` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_kemenkes`
--

INSERT INTO `tb_kemenkes` (`kode_obat`, `nama_obat`, `kemasan_dipersyaratkan`, `industri_farmasi`, `komitmen_nasional`, `rko_nasional`, `rko_lampung`, `hps_lampung`, `harga_lampung`, `rko_banten`, `hps_banten`, `harga_banten`, `rko_jakarta`, `hps_jakarta`, `harga_jakarta`, `rko_jawabarat`, `hps_jawabarat`, `harga_jawabarat`, `rko_jawatengah`, `hps_jawatengah`, `harga_jawatengah`, `rko_yogyakarta`, `hps_yogyakarta`, `harga_yogyakarta`, `rko_jawatimur`, `hps_jawatimur`, `harga_jawatimur`, `rko_bali`, `hps_bali`, `harga_bali`, `rko_sumaterautara`, `hps_sumaterautara`, `harga_sumaterautara`, `rko_sumaterabarat`, `hps_sumaterabarat`, `harga_sumaterabarat`, `rko_riau`, `hps_riau`, `harga_riau`, `rko_jambi`, `hps_jambi`, `harga_jambi`, `rko_sumateraselatan`, `hps_sumateraselatan`, `harga_sumateraselatan`, `rko_bengkulu`, `hps_bengkulu`, `harga_bengkulu`, `rko_kepulauanbangkabelitung`, `hps_kepulauanbangkabelitung`, `harga_kepulauanbangkabelitung`, `rko_nusatenggarabarat`, `hps_nusatenggarabarat`, `harga_nusatenggarabarat`, `rko_kepulauanriau`, `hps_kepulauanriau`, `harga_kepulauanriau`, `rko_aceh`, `hps_aceh`, `harga_aceh`, `rko_kalimantanbarat`, `hps_kalimantanbarat`, `harga_kalimantanbarat`, `rko_kalimantanselatan`, `hps_kalimantanselatan`, `harga_kalimantanselatan`, `rko_kalimantantimur`, `hps_kalimantantimur`, `harga_kalimantantimur`, `rko_sulawesiutara`, `hps_sulawesiutara`, `harga_sulawesiutara`, `rko_sulawesitengah`, `hps_sulawesitengah`, `harga_sulawesitengah`, `rko_sulawesiselatan`, `hps_sulawesiselatan`, `harga_sulawesiselatan`, `rko_kalimantanutara`, `hps_kalimantanutara`, `harga_kalimantanutara`, `rko_kalimantantengah`, `hps_kalimantantengah`, `harga_kalimantantengah`, `rko_sulawesitenggara`, `hps_sulawesitenggara`, `harga_sulawesitenggara`, `rko_gorontalo`, `hps_gorontalo`, `harga_gorontalo`, `rko_sulawesibarat`, `hps_sulawesibarat`, `harga_sulawesibarat`, `rko_nusatenggaratimur`, `hps_nusatenggaratimur`, `harga_nusatenggaratimur`, `rko_maluku`, `hps_maluku`, `harga_maluku`, `rko_malukuutara`, `hps_malukuutara`, `harga_malukuutara`, `rko_papuabarat`, `hps_papuabarat`, `harga_papuabarat`, `rko_papua`, `hps_papua`, `harga_papua`) VALUES
('6', 'panadol', 'strip/ blister', 'PT A', '40000000', '218875464', '5980446', '114', '97', '5331082', '114', '97', '6986076', '114', '97', '17059378', '114', '97', '15708364', '114', '97', '2217348', '114', '97', '26280262', '114', '97', '7748128', '114', '97', '10881738', '120', '97', '5764408', '120', '100', '3569144', '120', '100', '3877900', '120', '100', '5498582', '120', '97', '3288200', '120', '100', '626714', '120', '100', '2081184', '120', '100', '1769768', '131', '103', '34922002', '131', '131', '4921520', '131', '103', '3405448', '131', '103', '3747800', '131', '103', '4566888', '131', '103', '7488336', '131', '103', '3679642', '131', '103', '676784', '137', '106', '2155800', '137', '106', '1608100', '137', '106', '1849020', '137', '106', '4309400', '137', '106', '5198518', '143', '111', '2780248', '143', '111', '1573400', '143', '111', '6375108', '143', '111', '4948728', '143', '111'),
('6', 'panadol', 'strip/ blister', 'PT B', '250000000', '218875464', '5980446', '114', '110', '5331082', '114', '110', '6986076', '114', '110', '17059378', '114', '110', '15708364', '114', '110', '2217348', '114', '110', '26280262', '114', '110', '7748128', '114', '110', '10881738', '120', '112', '5764408', '120', '112', '3569144', '120', '112', '3877900', '120', '112', '5498582', '120', '112', '3288200', '120', '112', '626714', '120', '112', '2081184', '120', '112', '1769768', '131', '116', '34922002', '131', '116', '4921520', '131', '116', '3405448', '131', '116', '3747800', '131', '116', '4566888', '131', '116', '7488336', '131', '116', '3679642', '131', '116', '676784', '137', '120', '2155800', '137', '120', '1608100', '137', '120', '1849020', '137', '120', '4309400', '137', '120', '5198518', '143', '127', '2780248', '143', '127', '1573400', '143', '127', '6375108', '143', '127', '4948728', '143', '127'),
('6', 'panadol', 'strip/ blister', 'PT C', '220000000', '218875464', '5980446', '114', '104', '5331082', '114', '104', '6986076', '114', '99', '17059378', '114', '99', '15708364', '114', '99', '2217348', '114', '99', '26280262', '114', '99', '7748128', '114', '104', '10881738', '120', '99', '5764408', '120', '99', '3569144', '120', '104', '3877900', '120', '104', '5498582', '120', '99', '3288200', '120', '104', '626714', '120', '104', '2081184', '120', '104', '1769768', '131', '109', '34922002', '131', '109', '4921520', '131', '109', '3405448', '131', '109', '3747800', '131', '109', '4566888', '131', '109', '7488336', '131', '109', '3679642', '131', '99', '676784', '137', '104', '2155800', '137', '104', '1608100', '137', '104', '1849020', '137', '104', '4309400', '137', '104', '5198518', '143', '115', '2780248', '143', '115', '1573400', '143', '115', '6375108', '143', '115', '4948728', '143', '115'),
('6', 'panadol', 'strip/ blister', 'PT D', '250000000', '218875464', '5980446', '114', '108', '5331082', '114', '107', '6986076', '114', '108', '17059378', '114', '107', '15708364', '114', '107', '2217348', '114', '108', '26280262', '114', '107', '7748128', '114', '108', '10881738', '120', '112', '5764408', '120', '112', '3569144', '120', '112', '3877900', '120', '112', '5498582', '120', '112', '3288200', '120', '112', '626714', '120', '112', '2081184', '120', '112', '1769768', '131', '116', '34922002', '131', '116', '4921520', '131', '116', '3405448', '131', '116', '3747800', '131', '116', '4566888', '131', '116', '7488336', '131', '116', '3679642', '131', '116', '676784', '137', '116', '2155800', '137', '116', '1608100', '137', '116', '1849020', '137', '116', '4309400', '137', '116', '5198518', '143', '122', '2780248', '143', '122', '1573400', '143', '122', '6375108', '143', '122', '4948728', '143', '122'),
('6', 'panadol', 'strip/ blister', 'PT E', '300000000', '218875464', '5980446', '114', '112', '5331082', '114', '112', '6986076', '114', '112', '17059378', '114', '110', '15708364', '114', '110', '2217348', '114', '112', '26280262', '114', '110', '7748128', '114', '112', '10881738', '120', '116', '5764408', '120', '116', '3569144', '120', '116', '3877900', '120', '116', '5498582', '120', '116', '3288200', '120', '116', '626714', '120', '116', '2081184', '120', '116', '1769768', '131', '121', '34922002', '131', '119', '4921520', '131', '121', '3405448', '131', '121', '3747800', '131', '121', '4566888', '131', '121', '7488336', '131', '121', '3679642', '131', '121', '676784', '137', '125', '2155800', '137', '125', '1608100', '137', '125', '1849020', '137', '125', '4309400', '137', '125', '5198518', '143', '132', '2780248', '143', '132', '1573400', '143', '132', '6375108', '143', '132', '4948728', '143', '132'),
('6', 'panadol', 'strip/ blister', 'PT F', '220000000', '218875464', '5980446', '114', '106', '5331082', '114', '106', '6986076', '114', '106', '17059378', '114', '106', '15708364', '114', '106', '2217348', '114', '106', '26280262', '114', '106', '7748128', '114', '106', '10881738', '120', '106', '5764408', '120', '106', '3569144', '120', '106', '3877900', '120', '106', '5498582', '120', '106', '3288200', '120', '106', '626714', '120', '108', '2081184', '120', '108', '1769768', '131', '108', '34922002', '131', '108', '4921520', '131', '108', '3405448', '131', '108', '3747800', '131', '108', '4566888', '131', '113', '7488336', '131', '113', '3679642', '131', '113', '676784', '137', '113', '2155800', '137', '108', '1608100', '137', '113', '1849020', '137', '113', '4309400', '137', '113', '5198518', '143', '122', '2780248', '143', '122', '1573400', '143', '122', '6375108', '143', '122', '4948728', '143', '122'),
('6', 'panadol', 'strip/ blister', 'PT G', '229900000', '218875464', '5980446', '114', '99', '5331082', '114', '99', '6986076', '114', '99', '17059378', '114', '99', '15708364', '114', '99', '2217348', '114', '99', '26280262', '114', '99', '7748128', '114', '99', '10881738', '120', '99', '5764408', '120', '99', '3569144', '120', '99', '3877900', '120', '99', '5498582', '120', '99', '3288200', '120', '99', '626714', '120', '99', '2081184', '120', '99', '1769768', '131', '99', '34922002', '131', '99', '4921520', '131', '99', '3405448', '131', '99', '3747800', '131', '99', '4566888', '131', '99', '7488336', '131', '99', '3679642', '131', '99', '676784', '137', '102', '2155800', '137', '102', '1608100', '137', '102', '1849020', '137', '102', '4309400', '137', '102', '5198518', '143', '108', '2780248', '143', '108', '1573400', '143', '108', '6375108', '143', '108', '4948728', '143', '117'),
('6', 'panadol', 'strip/ blister', 'PT H', '219000000', '218875464', '5980446', '114', '147', '5331082', '114', '147', '6986076', '114', '147', '17059378', '114', '147', '15708364', '114', '147', '2217348', '114', '147', '26280262', '114', '147', '7748128', '114', '147', '10881738', '120', '152', '5764408', '120', '152', '3569144', '120', '152', '3877900', '120', '152', '5498582', '120', '152', '3288200', '120', '152', '626714', '120', '152', '2081184', '120', '152', '1769768', '131', '156', '34922002', '131', '156', '4921520', '131', '156', '3405448', '131', '156', '3747800', '131', '156', '4566888', '131', '156', '7488336', '131', '156', '3679642', '131', '156', '676784', '137', '162', '2155800', '137', '162', '1608100', '137', '162', '1849020', '137', '162', '4309400', '137', '162', '5198518', '143', '170', '2780248', '143', '170', '1573400', '143', '170', '6375108', '143', '170', '4948728', '143', '166'),
('6', 'panadol', 'strip/ blister', 'PT I', '164000000', '218875464', '5980446', '114', '113', '5331082', '114', '113', '6986076', '114', '113', '17059378', '114', '113', '15708364', '114', '113', '2217348', '114', '113', '26280262', '114', '113', '7748128', '114', '113', '10881738', '120', '115', '5764408', '120', '115', '3569144', '120', '115', '3877900', '120', '115', '5498582', '120', '115', '3288200', '120', '115', '626714', '120', '115', '2081184', '120', '115', '1769768', '131', '119', '34922002', '131', '119', '4921520', '131', '119', '3405448', '131', '119', '3747800', '131', '119', '4566888', '131', '119', '7488336', '131', '119', '3679642', '131', '119', '676784', '137', '120', '2155800', '137', '120', '1608100', '137', '120', '1849020', '137', '120', '4309400', '137', '120', '5198518', '143', '127', '2780248', '143', '127', '1573400', '143', '127', '6375108', '143', '127', '4948728', '143', '127'),
('6', 'panadol', 'strip/ blister', 'PT J', '100000000', '218875464', '5980446', '114', '93', '5331082', '114', '93', '6986076', '114', '93', '17059378', '114', '93', '15708364', '114', '93', '2217348', '114', '93', '26280262', '114', '93', '7748128', '114', '93', '10881738', '120', '95', '5764408', '120', '95', '3569144', '120', '95', '3877900', '120', '95', '5498582', '120', '95', '3288200', '120', '95', '626714', '120', '95', '2081184', '120', '95', '1769768', '131', '99', '34922002', '131', '99', '4921520', '131', '99', '3405448', '131', '99', '3747800', '131', '99', '4566888', '131', '99', '7488336', '131', '99', '3679642', '131', '99', '676784', '137', '105', '2155800', '137', '105', '1608100', '137', '105', '1849020', '137', '105', '4309400', '137', '105', '5198518', '143', '108', '2780248', '143', '108', '1573400', '143', '108', '6375108', '143', '108', '4948728', '143', '111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `download`
--
ALTER TABLE `download`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `download`
--
ALTER TABLE `download`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
