<?php
/*
-- Source Code from My Notes Code (www.mynotescode.com)
--
-- Follow Us on Social Media
-- Facebook : http://facebook.com/mynotescode/
-- Twitter  : http://twitter.com/mynotescode
-- Google+  : http://plus.google.com/118319575543333993544
--
-- Terimakasih telah mengunjungi blog kami.
-- Jangan lupa untuk Like dan Share catatan-catatan yang ada di blog kami.
*/

// Load file koneksi.php
include "../koneksi.php";

if(isset($_POST['import'])){ // Jika user mengklik tombol Import
	$nama_file_baru = 'dataallregional.xlsx';

	// Load librari PHPExcel nya
	require_once 'PHPExcel/PHPExcel.php';

	$excelreader = new PHPExcel_Reader_Excel2007();
	$loadexcel = $excelreader->load('tmp'.$nama_file_baru); // Load file excel yang tadi diupload ke folder tmp
	$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

	$numrow = 1;
	foreach($sheet as $row){
		// Ambil data pada excel sesuai Kolom
		$kode_obat = $row['A'];
                $nama_obat = $row['B'];
                $kemasan_dipersyaratkan = $row['C'];
                $industri_farmasi = $row['D'];
                $komitmen_nasional = $row['E'];
                $rko_nasional = $row['F'];
                $rko_lampung = $row['G'];
                $hps_lampung = $row['H'];
                $harga_lampung = $row['I'];
                $rko_banten = $row['J'];
                $hps_banten = $row['K'];
                $harga_banten = $row['L'];
                $rko_jakarta = $row['M'];
                $hps_jakarta = $row['N'];
                $harga_jakarta = $row['O'];
                $rko_jawabarat = $row['P'];
                $hps_jawabarat = $row['Q'];
                $harga_jawabarat = $row['R'];
                $rko_jawatengah = $row['S'];
                $hps_jawatengah = $row['T'];
                $harga_jawatengah = $row['U'];
                $rko_yogyakarta = $row['V'];
                $hps_yogyakarta = $row['W'];
                $harga_yogyakarta = $row['X'];
                $rko_jawatimur = $row['Y'];
                $hps_jawatimur = $row['Z'];
                $harga_jawatimur = $row['AA'];
                $rko_bali = $row['AB'];
                $hps_bali = $row['AC'];
                $harga_bali = $row['AD'];
                $rko_sumaterautara = $row['AE'];
                $hps_sumaterautara = $row['AF'];
                $harga_sumaterautara = $row['AG'];
                $rko_sumaterabarat = $row['AH'];
                $hps_sumaterabarat = $row['AI'];
                $harga_sumaterabarat = $row['AJ'];
                $rko_riau = $row['AK'];
                $hps_riau = $row['AL'];
                $harga_riau = $row['AM'];
                $rko_jambi = $row['AN'];
                $hps_jambi = $row['AO'];
                $harga_jambi = $row['AP'];
                $rko_sumateraselatan = $row['AQ'];
                $hps_sumateraselatan = $row['AR'];
                $harga_sumateraselatan = $row['AS'];
                $rko_bengkulu = $row['AT'];
                $hps_bengkulu = $row['AU'];
                $harga_bengkulu = $row['AV'];
                $rko_kepulauanbangkabelitung = $row['AW'];
                $hps_kepulauanbangkabelitung = $row['AX'];
                $harga_kepulauanbangkabelitung = $row['AY'];
                $rko_nusatenggarabarat = $row['AZ'];
                $hps_nusatenggarabarat = $row['BA'];
                $harga_nusatenggarabarat = $row['BB'];
                $rko_kepulauanriau = $row['BC'];
                $hps_kepulauanriau = $row['BD'];
                $harga_kepulauanriau = $row['BE'];
                $rko_aceh = $row['BF'];
                $hps_aceh = $row['BG'];
                $harga_aceh = $row['BH'];
                $rko_kalimantanbarat = $row['BI'];
                $hps_kalimantanbarat = $row['BJ'];
                $harga_kalimantanbarat = $row['BK'];
                $rko_kalimantanselatan = $row['BL'];
                $hps_kalimantanselatan = $row['BM'];
                $harga_kalimantanselatan = $row['BN'];
                $rko_kalimantantimur = $row['BO'];
                $hps_kalimantantimur = $row['BP'];
                $harga_kalimantantimur = $row['BQ'];
                $rko_sulawesiutara = $row['BR'];
                $hps_sulawesiutara = $row['BS'];
                $harga_sulawesiutara = $row['BT'];
                $rko_sulawesitengah = $row['BU'];
                $hps_sulawesitengah = $row['BV'];
                $harga_sulawesitengah = $row['BW'];
                $rko_sulawesiselatan = $row['BX'];
                $hps_sulawesiselatan = $row['BY'];
                $harga_sulawesiselatan = $row['BZ'];
                $rko_kalimantanutara = $row['CA'];
                $hps_kalimantanutara = $row['CB'];
                $harga_kalimantanutara = $row['CC'];
                $rko_kalimantantengah = $row['CD'];
                $hps_kalimantantengah = $row['CE'];
                $harga_kalimantantengah = $row['CF'];
                $rko_sulawesitenggara = $row['CG'];
                $hps_sulawesitenggara = $row['CH'];
                $harga_sulawesitenggara = $row['CI'];
                $rko_gorontalo = $row['CJ'];
                $hps_gorontalo = $row['CK'];
                $harga_gorontalo = $row['CL'];
                $rko_sulawesibarat = $row['CM'];
                $hps_sulawesibarat = $row['CN'];
                $harga_sulawesibarat = $row['CO'];
                $rko_nusatenggaratimur = $row['CP'];
                $hps_nusatenggaratimur = $row['CQ'];
                $harga_nusatenggaratimur = $row['CR'];
                $rko_maluku = $row['CS'];
                $hps_maluku = $row['CT'];
                $harga_maluku = $row['CU'];
                $rko_malukuutara = $row['CV'];
                $hps_malukuutara = $row['CW'];
                $harga_malukuutara = $row['CX'];
                $rko_papuabarat = $row['CY'];
                $hps_papuabarat = $row['CZ'];
                $harga_papuabarat = $row['DA'];
                $rko_papua = $row['DB'];
                $hps_papua = $row['DC'];
                $harga_papua = $row['DD'];

		// Cek jika semua data tidak diisi
		if(
			$kode_obat == ""
               && $nama_obat == ""
               && $kemasan_dipersyaratkan == ""
               && $industri_farmasi == ""
               && $komitmen_nasional == ""
               && $rko_nasional == ""
               && $rko_lampung == ""
               && $hps_lampung == ""
               && $harga_lampung == ""
               && $rko_banten == ""
               && $hps_banten == ""
               && $harga_banten == ""
               && $rko_jakarta == ""
               && $hps_jakarta == ""
               && $harga_jakarta == ""
               && $rko_jawabarat == ""
               && $hps_jawabarat == ""
               && $harga_jawabarat == ""
               && $rko_jawatengah == ""
               && $hps_jawatengah == ""
               && $harga_jawatengah == ""
               && $rko_yogyakarta == ""
               && $hps_yogyakarta == ""
               && $harga_yogyakarta == ""
               && $rko_jawatimur == ""
               && $hps_jawatimur == ""
               && $harga_jawatimur == ""
               && $rko_bali == ""
               && $hps_bali == ""
               && $harga_bali == ""
               && $rko_sumaterautara == ""
               && $hps_sumaterautara == ""
               && $harga_sumaterautara == ""
               && $rko_sumaterabarat == ""
               && $hps_sumaterabarat == ""
               && $harga_sumaterabarat == ""
               && $rko_riau == ""
               && $hps_riau == ""
               && $harga_riau == ""
               && $rko_jambi == ""
               && $hps_jambi == ""
               && $harga_jambi == ""
               && $rko_sumateraselatan == ""
               && $hps_sumateraselatan == ""
               && $harga_sumateraselatan == ""
               && $rko_bengkulu == ""
               && $hps_bengkulu == ""
               && $harga_bengkulu == ""
               && $rko_kepulauanbangkabelitung == ""
               && $hps_kepulauanbangkabelitung == ""
               && $harga_kepulauanbangkabelitung == ""
               && $rko_nusatenggarabarat == ""
               && $hps_nusatenggarabarat == ""
               && $harga_nusatenggarabarat == ""
               && $rko_kepulauanriau == ""
               && $hps_kepulauanriau == ""
               && $harga_kepulauanriau == ""
               && $rko_aceh == ""
               && $hps_aceh == ""
               && $harga_aceh == ""
               && $rko_kalimantanbarat == ""
               && $hps_kalimantanbarat == ""
               && $harga_kalimantanbarat == ""
               && $rko_kalimantanselatan == ""
               && $hps_kalimantanselatan == ""
               && $harga_kalimantanselatan == ""
               && $rko_kalimantantimur == ""
               && $hps_kalimantantimur == ""
               && $harga_kalimantantimur == ""
               && $rko_sulawesiutara == ""
               && $hps_sulawesiutara == ""
               && $harga_sulawesiutara == ""
               && $rko_sulawesitengah == ""
               && $hps_sulawesitengah == ""
               && $harga_sulawesitengah == ""
               && $rko_sulawesiselatan == ""
               && $hps_sulawesiselatan == ""
               && $harga_sulawesiselatan == ""
               && $rko_kalimantanutara == ""
               && $hps_kalimantanutara == ""
               && $harga_kalimantanutara == ""
               && $rko_kalimantantengah == ""
               && $hps_kalimantantengah == ""
               && $harga_kalimantantengah == ""
               && $rko_sulawesitenggara == ""
               && $hps_sulawesitenggara == ""
               && $harga_sulawesitenggara == ""
               && $rko_gorontalo == ""
               && $hps_gorontalo == ""
               && $harga_gorontalo == ""
               && $rko_sulawesibarat == ""
               && $hps_sulawesibarat == ""
               && $harga_sulawesibarat == ""
               && $rko_nusatenggaratimur == ""
               && $hps_nusatenggaratimur == ""
               && $harga_nusatenggaratimur == ""
               && $rko_maluku == ""
               && $hps_maluku == ""
               && $harga_maluku == ""
               && $rko_malukuutara == ""
               && $hps_malukuutara == ""
               && $harga_malukuutara == ""
               && $rko_papuabarat == ""
               && $hps_papuabarat == ""
               && $harga_papuabarat == ""
               && $rko_papua == ""
               && $hps_papua == ""
               && $harga_papua == ""
		)
			continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)

		// Cek $numrow apakah lebih dari 1
		// Artinya karena baris pertama adalah nama-nama kolom
		// Jadi dilewat saja, tidak usah diimport
		if($numrow > 1){
			// Buat query Insert
			$query = "INSERT INTO tb_kemenkes VALUES('".$kode_obat."','".$nama_obat."','".$kemasan_dipersyaratkan."','".$industri_farmasi."','".$komitmen_nasional."','".$rko_nasional."','".$rko_lampung."','".$hps_lampung."','".$harga_lampung."','".$rko_banten."','".$hps_banten."','".$harga_banten."','".$rko_jakarta."','".$hps_jakarta."','".$harga_jakarta."','".$rko_jawabarat."','".$hps_jawabarat."','".$harga_jawabarat."','".$rko_jawatengah."','".$hps_jawatengah."','".$harga_jawatengah."','".$rko_yogyakarta."','".$hps_yogyakarta."','".$harga_yogyakarta."','".$rko_jawatimur."','".$hps_jawatimur."','".$harga_jawatimur."','".$rko_bali."','".$hps_bali."','".$harga_bali."','".$rko_sumaterautara."','".$hps_sumaterautara."','".$harga_sumaterautara."','".$rko_sumaterabarat."','".$hps_sumaterabarat."','".$harga_sumaterabarat."','".$rko_riau."','".$hps_riau."','".$harga_riau."','".$rko_jambi."','".$hps_jambi."','".$harga_jambi."','".$rko_sumateraselatan."','".$hps_sumateraselatan."','".$harga_sumateraselatan."','".$rko_bengkulu."','".$hps_bengkulu."','".$harga_bengkulu."','".$rko_kepulauanbangkabelitung."','".$hps_kepulauanbangkabelitung."','".$harga_kepulauanbangkabelitung."','".$rko_nusatenggarabarat."','".$hps_nusatenggarabarat."','".$harga_nusatenggarabarat."','".$rko_kepulauanriau."','".$hps_kepulauanriau."','".$harga_kepulauanriau."','".$rko_aceh."','".$hps_aceh."','".$harga_aceh."','".$rko_kalimantanbarat."','".$hps_kalimantanbarat."','".$harga_kalimantanbarat."','".$rko_kalimantanselatan."','".$hps_kalimantanselatan."','".$harga_kalimantanselatan."','".$rko_kalimantantimur."','".$hps_kalimantantimur."','".$harga_kalimantantimur."','".$rko_sulawesiutara."','".$hps_sulawesiutara."','".$harga_sulawesiutara."','".$rko_sulawesitengah."','".$hps_sulawesitengah."','".$harga_sulawesitengah."','".$rko_sulawesiselatan."','".$hps_sulawesiselatan."','".$harga_sulawesiselatan."','".$rko_kalimantanutara."','".$hps_kalimantanutara."','".$harga_kalimantanutara."','".$rko_kalimantantengah."','".$hps_kalimantantengah."','".$harga_kalimantantengah."','".$rko_sulawesitenggara."','".$hps_sulawesitenggara."','".$harga_sulawesitenggara."','".$rko_gorontalo."','".$hps_gorontalo."','".$harga_gorontalo."','".$rko_sulawesibarat."','".$hps_sulawesibarat."','".$harga_sulawesibarat."','".$rko_nusatenggaratimur."','".$hps_nusatenggaratimur."','".$harga_nusatenggaratimur."','".$rko_maluku."','".$hps_maluku."','".$harga_maluku."','".$rko_malukuutara."','".$hps_malukuutara."','".$harga_malukuutara."','".$rko_papuabarat."','".$hps_papuabarat."','".$harga_papuabarat."','".$rko_papua."','".$hps_papua."','".$harga_papua."')";

			// Eksekusi $query
			mysqli_query($con, $query);
		}

		$numrow++; // Tambah 1 setiap kali looping
	}
}

header('location: home.php'); // Redirect ke halaman awal
?>
