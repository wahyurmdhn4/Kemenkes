<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headeradmin.php');
}else{
  include ('../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
  header("location:../index.php");
} ?>
<!-- /. NAV SIDE  -->

<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2>Import Data</h2>                           
       <!-- /. ROW  -->
       <link href="css/bootstrapform.min.css" rel="stylesheet">

       <style>
        #loading{
			background: whitesmoke;
			position: absolute;
			top: 140px;
			left: 82px;
			padding: 5px 10px;
			border: 1px solid #ccc;
		}
		</style>

		<script src="js/jquery1.min.js"></script>

		<script>
		$(document).ready(function(){
			// Sembunyikan alert validasi kosong
			$("#kosong").hide();
		});
		</script>

		<div style="padding: 0 15px;">
			<!-- Buat sebuah tombol Cancel untuk kemabli ke halaman awal / view data -->
			<a href="home.php" class="btn btn-danger pull-right">
				<span class="glyphicon glyphicon-remove"></span> Cancel
			</a>

			<h3>Form Import Data</h3>
			<hr>

			<!-- Buat sebuah tag form dan arahkan action nya ke file ini lagi -->
			<form method="post" action="" enctype="multipart/form-data">
				<a href="colom.xlsx" class="btn btn-default">
					<span class="glyphicon glyphicon-download"></span>
					Download Format
				</a><br><br>

				<!--
				-- Buat sebuah input type file
				-- class pull-left berfungsi agar file input berada di sebelah kiri
				-->
				<input type="file" name="file" class="pull-left">

				<button type="submit" name="preview" class="btn btn-success btn-sm">
					<span class="glyphicon glyphicon-eye-open"></span> Preview
				</button>
			</form>

			<hr>

			<!-- Buat Preview Data -->
			<?php
			// Jika user telah mengklik tombol Preview
			if(isset($_POST['preview'])){
				//$ip = ; // Ambil IP Address dari User
				$nama_file_baru = 'dataallregional.xlsx';

				// Cek apakah terdapat file data.xlsx pada folder tmp
				if(is_file('tmp'.$nama_file_baru)) // Jika file tersebut ada
					unlink('tmp'.$nama_file_baru); // Hapus file tersebut

				$ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION); // Ambil ekstensi filenya apa
				$tmp_file = $_FILES['file']['tmp_name'];

				// Cek apakah file yang diupload adalah file Excel 2007 (.xlsx)
				if($ext == "xlsx"){
					// Upload file yang dipilih ke folder tmp
					// dan rename file tersebut menjadi data{ip_address}.xlsx
					// {ip_address} diganti jadi ip address user yang ada di variabel $ip
					// Contoh nama file setelah di rename : data127.0.0.1.xlsx
					move_uploaded_file($tmp_file, 'tmp'.$nama_file_baru);

					// Load librari PHPExcel nya
					require_once 'PHPExcel/PHPExcel.php';

					$excelreader = new PHPExcel_Reader_Excel2007();
					$loadexcel = $excelreader->load('tmp'.$nama_file_baru); // Load file yang tadi diupload ke folder tmp
					$sheet = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

					// Buat sebuah tag form untuk proses import data ke database
					echo "<form method='post' action='import.php'>";

					// Buat sebuah div untuk alert validasi kosong
					/*echo "<div class='alert alert-danger' id='kosong'>
					Semua data sudah diisi, Ada <span id='jumlah_kosong'></span> data yang belum diisi.
					</div>";*/

					echo "<table class='table table-bordered'>
					<tr>
						<th colspan='5' class='text-center'>Preview Data</th>
					</tr>
					<tr>
                <th>kode_obat</th>
                <th>nama_obat</th>
                <th>kemasan_dipersyaratkan</th>
                <th>industri_farmasi</th>
                <th>komitmen_nasional</th>
                <th>rko_nasional</th>
                <th>rko_lampung</th>
                <th>hps_lampung</th>
                <th>harga_lampung</th>
                <th>rko_banten</th>
                <th>hps_banten</th>
                <th>harga_banten</th>
                <th>rko_jakarta</th>
                <th>hps_jakarta</th>
                <th>harga_jakarta</th>
                <th>rko_jawabarat</th>
                <th>hps_jawabarat</th>
                <th>harga_jawabarat</th>
                <th>rko_jawatengah</th>
                <th>hps_jawatengah</th>
                <th>harga_jawatengah</th>
                <th>rko_yogyakarta</th>
                <th>hps_yogyakarta</th>
                <th>harga_yogyakarta</th>
                <th>rko_jawatimur</th>
                <th>hps_jawatimur</th>
                <th>harga_jawatimur</th>
                <th>rko_bali</th>
                <th>hps_bali</th>
                <th>harga_bali</th>
                <th>rko_sumaterautara</th>
                <th>hps_sumaterautara</th>
                <th>harga_sumaterautara</th>
                <th>rko_sumaterabarat</th>
                <th>hps_sumaterabarat</th>
                <th>harga_sumaterabarat</th>
                <th>rko_riau</th>
                <th>hps_riau</th>
                <th>harga_riau</th>
                <th>rko_jambi</th>
                <th>hps_jambi</th>
                <th>harga_jambi</th>
                <th>rko_sumateraselatan</th>
                <th>hps_sumateraselatan</th>
                <th>harga_sumateraselatan</th>
                <th>rko_bengkulu</th>
                <th>hps_bengkulu</th>
                <th>harga_bengkulu</th>
                <th>rko_kepulauanbangkabelitung</th>
                <th>hps_kepulauanbangkabelitung</th>
                <th>harga_kepulauanbangkabelitung</th>
                <th>rko_nusatenggarabarat</th>
                <th>hps_nusatenggarabarat</th>
                <th>harga_nusatenggarabarat</th>
                <th>rko_kepulauanriau</th>
                <th>hps_kepulauanriau</th>
                <th>harga_kepulauanriau</th>
                <th>rko_aceh</th>
                <th>hps_aceh</th>
                <th>harga_aceh</th>
                <th>rko_kalimantanbarat</th>
                <th>hps_kalimantanbarat</th>
                <th>harga_kalimantanbarat</th>
                <th>rko_kalimantanselatan</th>
                <th>hps_kalimantanselatan</th>
                <th>harga_kalimantanselatan</th>
                <th>rko_kalimantantimur</th>
                <th>hps_kalimantantimur</th>
                <th>harga_kalimantantimur</th>
                <th>rko_sulawesiutara</th>
                <th>hps_sulawesiutara</th>
                <th>harga_sulawesiutara</th>
                <th>rko_sulawesitengah</th>
                <th>hps_sulawesitengah</th>
                <th>harga_sulawesitengah</th>
                <th>rko_sulawesiselatan</th>
                <th>hps_sulawesiselatan</th>
                <th>harga_sulawesiselatan</th>
                <th>rko_kalimantanutara</th>
                <th>hps_kalimantanutara</th>
                <th>harga_kalimantanutara</th>
                <th>rko_kalimantantengah</th>
                <th>hps_kalimantantengah</th>
                <th>harga_kalimantantengah</th>
                <th>rko_sulawesitenggara</th>
                <th>hps_sulawesitenggara</th>
                <th>harga_sulawesitenggara</th>
                <th>rko_gorontalo</th>
                <th>hps_gorontalo</th>
                <th>harga_gorontalo</th>
                <th>rko_sulawesibarat</th>
                <th>hps_sulawesibarat</th>
                <th>harga_sulawesibarat</th>
                <th>rko_nusatenggaratimur</th>
                <th>hps_nusatenggaratimur</th>
                <th>harga_nusatenggaratimur</th>
                <th>rko_maluku</th>
                <th>hps_maluku</th>
                <th>harga_maluku</th>
                <th>rko_malukuutara</th>
                <th>hps_malukuutara</th>
                <th>harga_malukuutara</th>
                <th>rko_papuabarat</th>
                <th>hps_papuabarat</th>
                <th>harga_papuabarat</th>
                <th>rko_papua</th>
                <th>hps_papua</th>
                <th>harga_papua</th>                      
              </tr>";

					$numrow = 1;
					$kosong = 0;
					foreach($sheet as $row){ // Lakukan perulangan dari data yang ada di excel
						// Ambil data pada excel sesuai Kolom
				$kode_obat = $row['A'];
                $nama_obat = $row['B'];
                $kemasan_dipersyaratkan = $row['C'];
                $industri_farmasi = $row['D'];
                $komitmen_nasional = $row['E'];
                $rko_nasional = $row['F'];
                $rko_lampung = $row['G'];
                $hps_lampung = $row['H'];
                $harga_lampung = $row['I'];
                $rko_banten = $row['J'];
                $hps_banten = $row['K'];
                $harga_banten = $row['L'];
                $rko_jakarta = $row['M'];
                $hps_jakarta = $row['N'];
                $harga_jakarta = $row['O'];
                $rko_jawabarat = $row['P'];
                $hps_jawabarat = $row['Q'];
                $harga_jawabarat = $row['R'];
                $rko_jawatengah = $row['S'];
                $hps_jawatengah = $row['T'];
                $harga_jawatengah = $row['U'];
                $rko_yogyakarta = $row['V'];
                $hps_yogyakarta = $row['W'];
                $harga_yogyakarta = $row['X'];
                $rko_jawatimur = $row['Y'];
                $hps_jawatimur = $row['Z'];
                $harga_jawatimur = $row['AA'];
                $rko_bali = $row['AB'];
                $hps_bali = $row['AC'];
                $harga_bali = $row['AD'];
                $rko_sumaterautara = $row['AE'];
                $hps_sumaterautara = $row['AF'];
                $harga_sumaterautara = $row['AG'];
                $rko_sumaterabarat = $row['AH'];
                $hps_sumaterabarat = $row['AI'];
                $harga_sumaterabarat = $row['AJ'];
                $rko_riau = $row['AK'];
                $hps_riau = $row['AL'];
                $harga_riau = $row['AM'];
                $rko_jambi = $row['AN'];
                $hps_jambi = $row['AO'];
                $harga_jambi = $row['AP'];
                $rko_sumateraselatan = $row['AQ'];
                $hps_sumateraselatan = $row['AR'];
                $harga_sumateraselatan = $row['AS'];
                $rko_bengkulu = $row['AT'];
                $hps_bengkulu = $row['AU'];
                $harga_bengkulu = $row['AV'];
                $rko_kepulauanbangkabelitung = $row['AW'];
                $hps_kepulauanbangkabelitung = $row['AX'];
                $harga_kepulauanbangkabelitung = $row['AY'];
                $rko_nusatenggarabarat = $row['AZ'];
                $hps_nusatenggarabarat = $row['BA'];
                $harga_nusatenggarabarat = $row['BB'];
                $rko_kepulauanriau = $row['BC'];
                $hps_kepulauanriau = $row['BD'];
                $harga_kepulauanriau = $row['BE'];
                $rko_aceh = $row['BF'];
                $hps_aceh = $row['BG'];
                $harga_aceh = $row['BH'];
                $rko_kalimantanbarat = $row['BI'];
                $hps_kalimantanbarat = $row['BJ'];
                $harga_kalimantanbarat = $row['BK'];
                $rko_kalimantanselatan = $row['BL'];
                $hps_kalimantanselatan = $row['BM'];
                $harga_kalimantanselatan = $row['BN'];
                $rko_kalimantantimur = $row['BO'];
                $hps_kalimantantimur = $row['BP'];
                $harga_kalimantantimur = $row['BQ'];
                $rko_sulawesiutara = $row['BR'];
                $hps_sulawesiutara = $row['BS'];
                $harga_sulawesiutara = $row['BT'];
                $rko_sulawesitengah = $row['BU'];
                $hps_sulawesitengah = $row['BV'];
                $harga_sulawesitengah = $row['BW'];
                $rko_sulawesiselatan = $row['BX'];
                $hps_sulawesiselatan = $row['BY'];
                $harga_sulawesiselatan = $row['BZ'];
                $rko_kalimantanutara = $row['CA'];
                $hps_kalimantanutara = $row['CB'];
                $harga_kalimantanutara = $row['CC'];
                $rko_kalimantantengah = $row['CD'];
                $hps_kalimantantengah = $row['CE'];
                $harga_kalimantantengah = $row['CF'];
                $rko_sulawesitenggara = $row['CG'];
                $hps_sulawesitenggara = $row['CH'];
                $harga_sulawesitenggara = $row['CI'];
                $rko_gorontalo = $row['CJ'];
                $hps_gorontalo = $row['CK'];
                $harga_gorontalo = $row['CL'];
                $rko_sulawesibarat = $row['CM'];
                $hps_sulawesibarat = $row['CN'];
                $harga_sulawesibarat = $row['CO'];
                $rko_nusatenggaratimur = $row['CP'];
                $hps_nusatenggaratimur = $row['CQ'];
                $harga_nusatenggaratimur = $row['CR'];
                $rko_maluku = $row['CS'];
                $hps_maluku = $row['CT'];
                $harga_maluku = $row['CU'];
                $rko_malukuutara = $row['CV'];
                $hps_malukuutara = $row['CW'];
                $harga_malukuutara = $row['CX'];
                $rko_papuabarat = $row['CY'];
                $hps_papuabarat = $row['CZ'];
                $harga_papuabarat = $row['DA'];
                $rko_papua = $row['DB'];
                $hps_papua = $row['DC'];
                $harga_papua = $row['DD'];


						// Cek jika semua data tidak diisi
						if($kode_obat == "" && $nama_obat == "" && $kemasan_dipersyaratkan == "" && $industri_farmasi == "" && $komitmen_nasional == "" && $rko_nasional == "" && $rko_lampung == "" && $hps_lampung == "" && $harga_lampung == "" && $rko_banten == "" && $hps_banten == "" && $harga_banten == "" && $rko_jakarta == "" && $hps_jakarta == "" && $harga_jakarta == "" && $rko_jawabarat == "" && $hps_jawabarat == "" && $harga_jawabarat == "" && $rko_jawatengah == "" && $hps_jawatengah == "" && $harga_jawatengah == "" && $rko_yogyakarta == "" && $hps_yogyakarta == "" && $harga_yogyakarta == "" && $rko_jawatimur == "" && $hps_jawatimur == "" && $harga_jawatimur == "" && $rko_bali == "" && $hps_bali == "" && $harga_bali == "" && $rko_sumaterautara == "" && $hps_sumaterautara == "" && $harga_sumaterautara == "" && $rko_sumaterabarat == "" && $hps_sumaterabarat == "" && $harga_sumaterabarat == "" && $rko_riau == "" && $hps_riau == "" && $harga_riau == "" && $rko_jambi == "" && $hps_jambi == "" && $harga_jambi == "" && $rko_sumateraselatan == "" && $hps_sumateraselatan == "" && $harga_sumateraselatan == "" && $rko_bengkulu == "" && $hps_bengkulu == "" && $harga_bengkulu == "" && $rko_kepulauanbangkabelitung == "" && $hps_kepulauanbangkabelitung == "" && $harga_kepulauanbangkabelitung == "" && $rko_nusatenggarabarat == "" && $hps_nusatenggarabarat == "" && $harga_nusatenggarabarat == "" && $rko_kepulauanriau == "" && $hps_kepulauanriau == "" && $harga_kepulauanriau == "" && $rko_aceh == "" && $hps_aceh == "" && $harga_aceh == "" && $rko_kalimantanbarat == "" && $hps_kalimantanbarat == "" && $harga_kalimantanbarat == "" && $rko_kalimantanselatan == "" && $hps_kalimantanselatan == "" && $harga_kalimantanselatan == "" && $rko_kalimantantimur == "" && $hps_kalimantantimur == "" && $harga_kalimantantimur == "" && $rko_sulawesiutara == "" && $hps_sulawesiutara == "" && $harga_sulawesiutara == "" && $rko_sulawesitengah == "" && $hps_sulawesitengah == "" && $harga_sulawesitengah == "" && $rko_sulawesiselatan == "" && $hps_sulawesiselatan == "" && $harga_sulawesiselatan == "" && $rko_kalimantanutara == "" && $hps_kalimantanutara == "" && $harga_kalimantanutara == "" && $rko_kalimantantengah == "" && $hps_kalimantantengah == "" && $harga_kalimantantengah == "" && $rko_sulawesitenggara == "" && $hps_sulawesitenggara == "" && $harga_sulawesitenggara == "" && $rko_gorontalo == "" && $hps_gorontalo == "" && $harga_gorontalo == "" && $rko_sulawesibarat == "" && $hps_sulawesibarat == "" && $harga_sulawesibarat == "" && $rko_nusatenggaratimur == "" && $hps_nusatenggaratimur == "" && $harga_nusatenggaratimur == "" && $rko_maluku == "" && $hps_maluku == "" && $harga_maluku == "" && $rko_malukuutara == "" && $hps_malukuutara == "" && $harga_malukuutara == "" && $rko_papuabarat == "" && $hps_papuabarat == "" && $harga_papuabarat == "" && $rko_papua == "" && $hps_papua == "" && $harga_papua == "")
							continue; // Lewat data pada baris ini (masuk ke looping selanjutnya / baris selanjutnya)

						// Cek $numrow apakah lebih dari 1
						// Artinya karena baris pertama adalah nama-nama kolom
						// Jadi dilewat saja, tidak usah diimport
						if($numrow > 1){
							// Validasi apakah semua data telah diisi
							$kode_obat_td = ( ! empty($kode_obat))? "" : " style='background: #E07171;'"; 
							$nama_obat_td = ( ! empty($nama_obat))? "" : " style='background: #E07171;'"; 
							$kemasan_dipersyaratkan_td = ( ! empty($kemasan_dipersyaratkan))? "" : " style='background: #E07171;'"; 
							$industri_farmasi_td = ( ! empty($industri_farmasi))? "" : " style='background: #E07171;'"; 
							$komitmen_nasional_td = ( ! empty($komitmen_nasional))? "" : " style='background: #E07171;'";
							$rko_nasional_td = ( ! empty ($rko_nasional))? "" : " style='background: #E07171;'";
                $rko_lampung_td = ( ! empty ($rko_lampung))? "" : " style='background: #E07171;'";
                $hps_lampung_td = ( ! empty ($hps_lampung))? "" : " style='background: #E07171;'";
                $harga_lampung_td = ( ! empty ($harga_lampung))? "" : " style='background: #E07171;'";
                $rko_banten_td = ( ! empty ($rko_banten))? "" : " style='background: #E07171;'";
                $hps_banten_td = ( ! empty ($hps_banten))? "" : " style='background: #E07171;'";
                $harga_banten_td = ( ! empty ($harga_banten))? "" : " style='background: #E07171;'";
                $rko_jakarta_td = ( ! empty ($rko_jakarta))? "" : " style='background: #E07171;'";
                $hps_jakarta_td = ( ! empty ($hps_jakarta))? "" : " style='background: #E07171;'";
                $harga_jakarta_td = ( ! empty ($harga_jakarta))? "" : " style='background: #E07171;'";
                $rko_jawabarat_td = ( ! empty ($rko_jawabarat))? "" : " style='background: #E07171;'";
                $hps_jawabarat_td = ( ! empty ($hps_jawabarat))? "" : " style='background: #E07171;'";
                $harga_jawabarat_td = ( ! empty ($harga_jawabarat))? "" : " style='background: #E07171;'";
                $rko_jawatengah_td = ( ! empty ($rko_jawatengah))? "" : " style='background: #E07171;'";
                $hps_jawatengah_td = ( ! empty ($hps_jawatengah))? "" : " style='background: #E07171;'";
                $harga_jawatengah_td = ( ! empty ($harga_jawatengah))? "" : " style='background: #E07171;'";
                $rko_yogyakarta_td = ( ! empty ($rko_yogyakarta))? "" : " style='background: #E07171;'";
                $hps_yogyakarta_td = ( ! empty ($hps_yogyakarta))? "" : " style='background: #E07171;'";
                $harga_yogyakarta_td = ( ! empty ($harga_yogyakarta))? "" : " style='background: #E07171;'";
                $rko_jawatimur_td = ( ! empty ($rko_jawatimur))? "" : " style='background: #E07171;'";
                $hps_jawatimur_td = ( ! empty ($hps_jawatimur))? "" : " style='background: #E07171;'";
                $harga_jawatimur_td = ( ! empty ($harga_jawatimur))? "" : " style='background: #E07171;'";
                $rko_bali_td = ( ! empty ($rko_bali))? "" : " style='background: #E07171;'";
                $hps_bali_td = ( ! empty ($hps_bali))? "" : " style='background: #E07171;'";
                $harga_bali_td = ( ! empty ($harga_bali))? "" : " style='background: #E07171;'";
                $rko_sumaterautara_td = ( ! empty ($rko_sumaterautara))? "" : " style='background: #E07171;'";
                $hps_sumaterautara_td = ( ! empty ($hps_sumaterautara))? "" : " style='background: #E07171;'";
                $harga_sumaterautara_td = ( ! empty ($harga_sumaterautara))? "" : " style='background: #E07171;'";
                $rko_sumaterabarat_td = ( ! empty ($rko_sumaterabarat))? "" : " style='background: #E07171;'";
                $hps_sumaterabarat_td = ( ! empty ($hps_sumaterabarat))? "" : " style='background: #E07171;'";
                $harga_sumaterabarat_td = ( ! empty ($harga_sumaterabarat))? "" : " style='background: #E07171;'";
                $rko_riau_td = ( ! empty ($rko_riau))? "" : " style='background: #E07171;'";
                $hps_riau_td = ( ! empty ($hps_riau))? "" : " style='background: #E07171;'";
                $harga_riau_td = ( ! empty ($harga_riau))? "" : " style='background: #E07171;'";
                $rko_jambi_td = ( ! empty ($rko_jambi))? "" : " style='background: #E07171;'";
                $hps_jambi_td = ( ! empty ($hps_jambi))? "" : " style='background: #E07171;'";
                $harga_jambi_td = ( ! empty ($harga_jambi))? "" : " style='background: #E07171;'";
                $rko_sumateraselatan_td = ( ! empty ($rko_sumateraselatan))? "" : " style='background: #E07171;'";
                $hps_sumateraselatan_td = ( ! empty ($hps_sumateraselatan))? "" : " style='background: #E07171;'";
                $harga_sumateraselatan_td = ( ! empty ($harga_sumateraselatan))? "" : " style='background: #E07171;'";
                $rko_bengkulu_td = ( ! empty ($rko_bengkulu))? "" : " style='background: #E07171;'";
                $hps_bengkulu_td = ( ! empty ($hps_bengkulu))? "" : " style='background: #E07171;'";
                $harga_bengkulu_td = ( ! empty ($harga_bengkulu))? "" : " style='background: #E07171;'";
                $rko_kepulauanbangkabelitung_td = ( ! empty ($rko_kepulauanbangkabelitung))? "" : " style='background: #E07171;'";
                $hps_kepulauanbangkabelitung_td = ( ! empty ($hps_kepulauanbangkabelitung))? "" : " style='background: #E07171;'";
                $harga_kepulauanbangkabelitung_td = ( ! empty ($harga_kepulauanbangkabelitung))? "" : " style='background: #E07171;'";
                $rko_nusatenggarabarat_td = ( ! empty ($rko_nusatenggarabarat))? "" : " style='background: #E07171;'";
                $hps_nusatenggarabarat_td = ( ! empty ($hps_nusatenggarabarat))? "" : " style='background: #E07171;'";
                $harga_nusatenggarabarat_td = ( ! empty ($harga_nusatenggarabarat))? "" : " style='background: #E07171;'";
                $rko_kepulauanriau_td = ( ! empty ($rko_kepulauanriau))? "" : " style='background: #E07171;'";
                $hps_kepulauanriau_td = ( ! empty ($hps_kepulauanriau))? "" : " style='background: #E07171;'";
                $harga_kepulauanriau_td = ( ! empty ($harga_kepulauanriau))? "" : " style='background: #E07171;'";
                $rko_aceh_td = ( ! empty ($rko_aceh))? "" : " style='background: #E07171;'";
                $hps_aceh_td = ( ! empty ($hps_aceh))? "" : " style='background: #E07171;'";
                $harga_aceh_td = ( ! empty ($harga_aceh))? "" : " style='background: #E07171;'";
                $rko_kalimantanbarat_td = ( ! empty ($rko_kalimantanbarat))? "" : " style='background: #E07171;'";
                $hps_kalimantanbarat_td = ( ! empty ($hps_kalimantanbarat))? "" : " style='background: #E07171;'";
                $harga_kalimantanbarat_td = ( ! empty ($harga_kalimantanbarat))? "" : " style='background: #E07171;'";
                $rko_kalimantanselatan_td = ( ! empty ($rko_kalimantanselatan))? "" : " style='background: #E07171;'";
                $hps_kalimantanselatan_td = ( ! empty ($hps_kalimantanselatan))? "" : " style='background: #E07171;'";
                $harga_kalimantanselatan_td = ( ! empty ($harga_kalimantanselatan))? "" : " style='background: #E07171;'";
                $rko_kalimantantimur_td = ( ! empty ($rko_kalimantantimur))? "" : " style='background: #E07171;'";
                $hps_kalimantantimur_td = ( ! empty ($hps_kalimantantimur))? "" : " style='background: #E07171;'";
                $harga_kalimantantimur_td = ( ! empty ($harga_kalimantantimur))? "" : " style='background: #E07171;'";
                $rko_sulawesiutara_td = ( ! empty ($rko_sulawesiutara))? "" : " style='background: #E07171;'";
                $hps_sulawesiutara_td = ( ! empty ($hps_sulawesiutara))? "" : " style='background: #E07171;'";
                $harga_sulawesiutara_td = ( ! empty ($harga_sulawesiutara))? "" : " style='background: #E07171;'";
                $rko_sulawesitengah_td = ( ! empty ($rko_sulawesitengah))? "" : " style='background: #E07171;'";
                $hps_sulawesitengah_td = ( ! empty ($hps_sulawesitengah))? "" : " style='background: #E07171;'";
                $harga_sulawesitengah_td = ( ! empty ($harga_sulawesitengah))? "" : " style='background: #E07171;'";
                $rko_sulawesiselatan_td = ( ! empty ($rko_sulawesiselatan))? "" : " style='background: #E07171;'";
                $hps_sulawesiselatan_td = ( ! empty ($hps_sulawesiselatan))? "" : " style='background: #E07171;'";
                $harga_sulawesiselatan_td = ( ! empty ($harga_sulawesiselatan))? "" : " style='background: #E07171;'";
                $rko_kalimantanutara_td = ( ! empty ($rko_kalimantanutara))? "" : " style='background: #E07171;'";
                $hps_kalimantanutara_td = ( ! empty ($hps_kalimantanutara))? "" : " style='background: #E07171;'";
                $harga_kalimantanutara_td = ( ! empty ($harga_kalimantanutara))? "" : " style='background: #E07171;'";
                $rko_kalimantantengah_td = ( ! empty ($rko_kalimantantengah))? "" : " style='background: #E07171;'";
                $hps_kalimantantengah_td = ( ! empty ($hps_kalimantantengah))? "" : " style='background: #E07171;'";
                $harga_kalimantantengah_td = ( ! empty ($harga_kalimantantengah))? "" : " style='background: #E07171;'";
                $rko_sulawesitenggara_td = ( ! empty ($rko_sulawesitenggara))? "" : " style='background: #E07171;'";
                $hps_sulawesitenggara_td = ( ! empty ($hps_sulawesitenggara))? "" : " style='background: #E07171;'";
                $harga_sulawesitenggara_td = ( ! empty ($harga_sulawesitenggara))? "" : " style='background: #E07171;'";
                $rko_gorontalo_td = ( ! empty ($rko_gorontalo))? "" : " style='background: #E07171;'";
                $hps_gorontalo_td = ( ! empty ($hps_gorontalo))? "" : " style='background: #E07171;'";
                $harga_gorontalo_td = ( ! empty ($harga_gorontalo))? "" : " style='background: #E07171;'";
                $rko_sulawesibarat_td = ( ! empty ($rko_sulawesibarat))? "" : " style='background: #E07171;'";
                $hps_sulawesibarat_td = ( ! empty ($hps_sulawesibarat))? "" : " style='background: #E07171;'";
                $harga_sulawesibarat_td = ( ! empty ($harga_sulawesibarat))? "" : " style='background: #E07171;'";
                $rko_nusatenggaratimur_td = ( ! empty ($rko_nusatenggaratimur))? "" : " style='background: #E07171;'";
                $hps_nusatenggaratimur_td = ( ! empty ($hps_nusatenggaratimur))? "" : " style='background: #E07171;'";
                $harga_nusatenggaratimur_td = ( ! empty ($harga_nusatenggaratimur))? "" : " style='background: #E07171;'";
                $rko_maluku_td = ( ! empty ($rko_maluku))? "" : " style='background: #E07171;'";
                $hps_maluku_td = ( ! empty ($hps_maluku))? "" : " style='background: #E07171;'";
                $harga_maluku_td = ( ! empty ($harga_maluku))? "" : " style='background: #E07171;'";
                $rko_malukuutara_td = ( ! empty ($rko_malukuutara))? "" : " style='background: #E07171;'";
                $hps_malukuutara_td = ( ! empty ($hps_malukuutara))? "" : " style='background: #E07171;'";
                $harga_malukuutara_td = ( ! empty ($harga_malukuutara))? "" : " style='background: #E07171;'";
                $rko_papuabarat_td = ( ! empty ($rko_papuabarat))? "" : " style='background: #E07171;'";
                $hps_papuabarat_td = ( ! empty ($hps_papuabarat))? "" : " style='background: #E07171;'";
                $harga_papuabarat_td = ( ! empty ($harga_papuabarat))? "" : " style='background: #E07171;'";
                $rko_papua_td = ( ! empty ($rko_papua))? "" : " style='background: #E07171;'";
                $hps_papua_td = ( ! empty ($hps_papua))? "" : " style='background: #E07171;'";
                $harga_papua_td = ( ! empty ($harga_papua))? "" : " style='background: #E07171;'";

							// Jika salah satu data ada yang kosong
							if($kode_obat == "" or $nama_obat == ""or $kemasan_dipersyaratkan == "" or $industri_farmasi == "" or $komitmen_nasional == "" or $rko_nasional == "" or $rko_lampung == "" or $hps_lampung == "" or $harga_lampung == "" or $rko_banten == "" or $hps_banten == "" or $harga_banten == "" or $rko_jakarta == "" or $hps_jakarta == "" or $harga_jakarta == "" or $rko_jawabarat == "" or $hps_jawabarat == "" or $harga_jawabarat == "" or $rko_jawatengah == "" or $hps_jawatengah == "" or $harga_jawatengah == "" or $rko_yogyakarta == "" or $hps_yogyakarta == "" or $harga_yogyakarta == "" or $rko_jawatimur == "" or $hps_jawatimur == "" or $harga_jawatimur == "" or $rko_bali == "" or $hps_bali == "" or $harga_bali == "" or $rko_sumaterautara == "" or $hps_sumaterautara == "" or $harga_sumaterautara == "" or $rko_sumaterabarat == "" or $hps_sumaterabarat == "" or $harga_sumaterabarat == "" or $rko_riau == "" or $hps_riau == "" or $harga_riau == "" or $rko_jambi == "" or $hps_jambi == "" or $harga_jambi == "" or $rko_sumateraselatan == "" or $hps_sumateraselatan == "" or $harga_sumateraselatan == "" or $rko_bengkulu == "" or $hps_bengkulu == "" or $harga_bengkulu == "" or $rko_kepulauanbangkabelitung == "" or $hps_kepulauanbangkabelitung == "" or $harga_kepulauanbangkabelitung == "" or $rko_nusatenggarabarat == "" or $hps_nusatenggarabarat == "" or $harga_nusatenggarabarat == "" or $rko_kepulauanriau == "" or $hps_kepulauanriau == "" or $harga_kepulauanriau == "" or $rko_aceh == "" or $hps_aceh == "" or $harga_aceh == "" or $rko_kalimantanbarat == "" or $hps_kalimantanbarat == "" or $harga_kalimantanbarat == "" or $rko_kalimantanselatan == "" or $hps_kalimantanselatan == "" or $harga_kalimantanselatan == "" or $rko_kalimantantimur == "" or $hps_kalimantantimur == "" or $harga_kalimantantimur == "" or $rko_sulawesiutara == "" or $hps_sulawesiutara == "" or $harga_sulawesiutara == "" or $rko_sulawesitengah == "" or $hps_sulawesitengah == "" or $harga_sulawesitengah == "" or $rko_sulawesiselatan == "" or $hps_sulawesiselatan == "" or $harga_sulawesiselatan == "" or $rko_kalimantanutara == "" or $hps_kalimantanutara == "" or $harga_kalimantanutara == "" or $rko_kalimantantengah == "" or $hps_kalimantantengah == "" or $harga_kalimantantengah == "" or $rko_sulawesitenggara == "" or $hps_sulawesitenggara == "" or $harga_sulawesitenggara == "" or $rko_gorontalo == "" or $hps_gorontalo == "" or $harga_gorontalo == "" or $rko_sulawesibarat == "" or $hps_sulawesibarat == "" or $harga_sulawesibarat == "" or $rko_nusatenggaratimur == "" or $hps_nusatenggaratimur == "" or $harga_nusatenggaratimur == "" or $rko_maluku == "" or $hps_maluku == "" or $harga_maluku == "" or $rko_malukuutara == "" or $hps_malukuutara == "" or $harga_malukuutara == "" or $rko_papuabarat == "" or $hps_papuabarat == "" or $harga_papuabarat == "" or $rko_papua == "" or $hps_papua == "" or $harga_papua == ""){
								$kosong++; // Tambah 1 variabel $kosong
							}

				echo "<tr>";
				echo "<td".$kode_obat_td.">".$kode_obat."</td>";
				echo "<td".$nama_obat_td.">".$nama_obat."</td>";
				echo "<td".$kemasyaratkan_dipersyaratkan_td.">".$kemasan_dipersyaratkan."</td>";
				echo "<td".$industri_farmasi_td.">".$industri_farmasi."</td>";
				echo "<td".$komitmen_nasional_td.">".$komitmen_nasional."</td>";
				echo "<td".$rko_nasional_td.">".$rko_nasional."</td>";
                echo "<td".$rko_lampung_td.">".$rko_lampung."</td>";
                echo "<td".$hps_lampung_td.">".$hps_lampung."</td>";
                echo "<td".$harga_lampung_td.">".$harga_lampung."</td>";
                echo "<td".$rko_banten_td.">".$rko_banten."</td>";
                echo "<td".$hps_banten_td.">".$hps_banten."</td>";
                echo "<td".$harga_banten_td.">".$harga_banten."</td>";
                echo "<td".$rko_jakarta_td.">".$rko_jakarta."</td>";
                echo "<td".$hps_jakarta_td.">".$hps_jakarta."</td>";
                echo "<td".$harga_jakarta_td.">".$harga_jakarta."</td>";
                echo "<td".$rko_jawabarat_td.">".$rko_jawabarat."</td>";
                echo "<td".$hps_jawabarat_td.">".$hps_jawabarat."</td>";
                echo "<td".$harga_jawabarat_td.">".$harga_jawabarat."</td>";
                echo "<td".$rko_jawatengah_td.">".$rko_jawatengah."</td>";
                echo "<td".$hps_jawatengah_td.">".$hps_jawatengah."</td>";
                echo "<td".$harga_jawatengah_td.">".$harga_jawatengah."</td>";
                echo "<td".$rko_yogyakarta_td.">".$rko_yogyakarta."</td>";
                echo "<td".$hps_yogyakarta_td.">".$hps_yogyakarta."</td>";
                echo "<td".$harga_yogyakarta_td.">".$harga_yogyakarta."</td>";
                echo "<td".$rko_jawatimur_td.">".$rko_jawatimur."</td>";
                echo "<td".$hps_jawatimur_td.">".$hps_jawatimur."</td>";
                echo "<td".$harga_jawatimur_td.">".$harga_jawatimur."</td>";
                echo "<td".$rko_bali_td.">".$rko_bali."</td>";
                echo "<td".$hps_bali_td.">".$hps_bali."</td>";
                echo "<td".$harga_bali_td.">".$harga_bali."</td>";
                echo "<td".$rko_sumaterautara_td.">".$rko_sumaterautara."</td>";
                echo "<td".$hps_sumaterautara_td.">".$hps_sumaterautara."</td>";
                echo "<td".$harga_sumaterautara_td.">".$harga_sumaterautara."</td>";
                echo "<td".$rko_sumaterabarat_td.">".$rko_sumaterabarat."</td>";
                echo "<td".$hps_sumaterabarat_td.">".$hps_sumaterabarat."</td>";
                echo "<td".$harga_sumaterabarat_td.">".$harga_sumaterabarat."</td>";
                echo "<td".$rko_riau_td.">".$rko_riau."</td>";
                echo "<td".$hps_riau_td.">".$hps_riau."</td>";
                echo "<td".$harga_riau_td.">".$harga_riau."</td>";
                echo "<td".$rko_jambi_td.">".$rko_jambi."</td>";
                echo "<td".$hps_jambi_td.">".$hps_jambi."</td>";
                echo "<td".$harga_jambi_td.">".$harga_jambi."</td>";
                echo "<td".$rko_sumateraselatan_td.">".$rko_sumateraselatan."</td>";
                echo "<td".$hps_sumateraselatan_td.">".$hps_sumateraselatan."</td>";
                echo "<td".$harga_sumateraselatan_td.">".$harga_sumateraselatan."</td>";
                echo "<td".$rko_bengkulu_td.">".$rko_bengkulu."</td>";
                echo "<td".$hps_bengkulu_td.">".$hps_bengkulu."</td>";
                echo "<td".$harga_bengkulu_td.">".$harga_bengkulu."</td>";
                echo "<td".$rko_kepulauanbangkabelitung_td.">".$rko_kepulauanbangkabelitung."</td>";
                echo "<td".$hps_kepulauanbangkabelitung_td.">".$hps_kepulauanbangkabelitung."</td>";
                echo "<td".$harga_kepulauanbangkabelitung_td.">".$harga_kepulauanbangkabelitung."</td>";
                echo "<td".$rko_nusatenggarabarat_td.">".$rko_nusatenggarabarat."</td>";
                echo "<td".$hps_nusatenggarabarat_td.">".$hps_nusatenggarabarat."</td>";
                echo "<td".$harga_nusatenggarabarat_td.">".$harga_nusatenggarabarat."</td>";
                echo "<td".$rko_kepulauanriau_td.">".$rko_kepulauanriau."</td>";
                echo "<td".$hps_kepulauanriau_td.">".$hps_kepulauanriau."</td>";
                echo "<td".$harga_kepulauanriau_td.">".$harga_kepulauanriau."</td>";
                echo "<td".$rko_aceh_td.">".$rko_aceh."</td>";
                echo "<td".$hps_aceh_td.">".$hps_aceh."</td>";
                echo "<td".$harga_aceh_td.">".$harga_aceh."</td>";
                echo "<td".$rko_kalimantanbarat_td.">".$rko_kalimantanbarat."</td>";
                echo "<td".$hps_kalimantanbarat_td.">".$hps_kalimantanbarat."</td>";
                echo "<td".$harga_kalimantanbarat_td.">".$harga_kalimantanbarat."</td>";
                echo "<td".$rko_kalimantanselatan_td.">".$rko_kalimantanselatan."</td>";
                echo "<td".$hps_kalimantanselatan_td.">".$hps_kalimantanselatan."</td>";
                echo "<td".$harga_kalimantanselatan_td.">".$harga_kalimantanselatan."</td>";
                echo "<td".$rko_kalimantantimur_td.">".$rko_kalimantantimur."</td>";
                echo "<td".$hps_kalimantantimur_td.">".$hps_kalimantantimur."</td>";
                echo "<td".$harga_kalimantantimur_td.">".$harga_kalimantantimur."</td>";
                echo "<td".$rko_sulawesiutara_td.">".$rko_sulawesiutara."</td>";
                echo "<td".$hps_sulawesiutara_td.">".$hps_sulawesiutara."</td>";
                echo "<td".$harga_sulawesiutara_td.">".$harga_sulawesiutara."</td>";
                echo "<td".$rko_sulawesitengah_td.">".$rko_sulawesitengah."</td>";
                echo "<td".$hps_sulawesitengah_td.">".$hps_sulawesitengah."</td>";
                echo "<td".$harga_sulawesitengah_td.">".$harga_sulawesitengah."</td>";
                echo "<td".$rko_sulawesiselatan_td.">".$rko_sulawesiselatan."</td>";
                echo "<td".$hps_sulawesiselatan_td.">".$hps_sulawesiselatan."</td>";
                echo "<td".$harga_sulawesiselatan_td.">".$harga_sulawesiselatan."</td>";
                echo "<td".$rko_kalimantanutara_td.">".$rko_kalimantanutara."</td>";
                echo "<td".$hps_kalimantanutara_td.">".$hps_kalimantanutara."</td>";
                echo "<td".$harga_kalimantanutara_td.">".$harga_kalimantanutara."</td>";
                echo "<td".$rko_kalimantantengah_td.">".$rko_kalimantantengah."</td>";
                echo "<td".$hps_kalimantantengah_td.">".$hps_kalimantantengah."</td>";
                echo "<td".$harga_kalimantantengah_td.">".$harga_kalimantantengah."</td>";
                echo "<td".$rko_sulawesitenggara_td.">".$rko_sulawesitenggara."</td>";
                echo "<td".$hps_sulawesitenggara_td.">".$hps_sulawesitenggara."</td>";
                echo "<td".$harga_sulawesitenggara_td.">".$harga_sulawesitenggara."</td>";
                echo "<td".$rko_gorontalo_td.">".$rko_gorontalo."</td>";
                echo "<td".$hps_gorontalo_td.">".$hps_gorontalo."</td>";
                echo "<td".$harga_gorontalo_td.">".$harga_gorontalo."</td>";
                echo "<td".$rko_sulawesibarat_td.">".$rko_sulawesibarat."</td>";
                echo "<td".$hps_sulawesibarat_td.">".$hps_sulawesibarat."</td>";
                echo "<td".$harga_sulawesibarat_td.">".$harga_sulawesibarat."</td>";
                echo "<td".$rko_nusatenggaratimur_td.">".$rko_nusatenggaratimur."</td>";
                echo "<td".$hps_nusatenggaratimur_td.">".$hps_nusatenggaratimur."</td>";
                echo "<td".$harga_nusatenggaratimur_td.">".$harga_nusatenggaratimur."</td>";
                echo "<td".$rko_maluku_td.">".$rko_maluku."</td>";
                echo "<td".$hps_maluku_td.">".$hps_maluku."</td>";
                echo "<td".$harga_maluku_td.">".$harga_maluku."</td>";
                echo "<td".$rko_malukuutara_td.">".$rko_malukuutara."</td>";
                echo "<td".$hps_malukuutara_td.">".$hps_malukuutara."</td>";
                echo "<td".$harga_malukuutara_td.">".$harga_malukuutara."</td>";
                echo "<td".$rko_papuabarat_td.">".$rko_papuabarat."</td>";
                echo "<td".$hps_papuabarat_td.">".$hps_papuabarat."</td>";
                echo "<td".$harga_papuabarat_td.">".$harga_papuabarat."</td>";
                echo "<td".$rko_papua_td.">".$rko_papua."</td>";
                echo "<td".$hps_papua_td.">".$hps_papua."</td>";
                echo "<td".$harga_papua_td.">".$harga_papua."</td>";
				echo "</tr>";
						}

						$numrow++; // Tambah 1 setiap kali looping
					}

					echo "</table>";

					// Cek apakah variabel kosong lebih dari 1
					// Jika lebih dari 1, berarti ada data yang masih kosong
					if($kosong > 1){
					?>
						<script>
						$(document).ready(function(){
							// Ubah isi dari tag span dengan id jumlah_kosong dengan isi dari variabel kosong
							$("#jumlah_kosong").html('<?php echo $kosong; ?>');

							$("#kosong").show(); // Munculkan alert validasi kosong
						});
						</script>
					<?php
					}else{ // Jika semua data sudah diisi
						echo "<hr>";

						// Buat sebuah tombol untuk mengimport data ke database
						echo "<button type='submit' name='import' class='btn btn-primary'><span class='glyphicon glyphicon-upload'></span> Import</button>";
					}

					echo "</form>";
				}else{ // Jika file yang diupload bukan File Excel 2007 (.xlsx)
					// Munculkan pesan validasi
					echo "<div class='alert alert-danger'>
					Hanya File Excel 2007 (.xlsx) yang diperbolehkan
					</div>";
				}
			}
			?>
		</div>                            
       
    </div> 
    <!-- /. PAGE INNER  -->
  </div>
  <!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  -->  

<?php
include "../library/footeradmin.php";
?>      