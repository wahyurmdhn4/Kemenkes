<?php 
include ('../mysql.php');
include('../config.php');
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headeradmin.php');
}else{
  include ('../library/header.php');
}
?>

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../index.php");
    } ?>


        <div id="page-wrapper" >
          <div id="page-inner">
              <div class="row">
                <div class="col-md-12">
                 <h2>Pendaftaran File</h2>                          
               </div>
             </div>              
             <!-- /. ROW  -->
             <hr />
             <div class="row">
              <!-- start content -->
 <!DOCTYPE html>
<html>
<head>
    <title>Upload dan Download File</title>    
</head>
<style>
 @charset "utf-8";
/* CSS Document */

h1, h2, h3 {
  margin:0;
  padding:0;
}

#container {
  width:1100px;
  margin:20px auto;
  padding:10px;
  background-color:#fff;
  box-shadow:0px 0px 3px #000;
}

#header {
  text-align:center;
}

#menu {
  text-align:center;
  margin:15px 0px;
  border-top:1px solid #CCC;
  border-bottom:1px solid #CCC;
}

  #menu a {
    display:inline-block;
    padding:5px 10px;
    text-decoration:none;
    color:#000;
    font-weight:bold;
  }
  
    #menu a:hover {
      background-color:#CCC;
    }
    
    #menu a.active {
      background-color:#CCC;
    }

.table, th, td {
  border-collapse:collapse;
  border:1px solid #ccc;
}

  .table th {
    background-color:#CCC;
  }
  
.error {
  border:1px solid #FF8080;
  background-color:#FFCECE;
  padding:3px;
  margin:5px 0px;
  text-align:center;
}

.ok {
  border:1px solid #80FF80;
  background-color:#CFC;
  padding:3px;
  margin:5px 0px;
  text-align:center;
} 
</style>

<body>

    <div class="col-md-12">
        <div id="header">
            <h1>Upload dan Download File</h1>
            <span>Dibuat oleh Rifki Abdillah</span>
        </div>    
        <div id="menu">
          
            <a href="upload.php" class="active">Upload</a>
            <a href="download.php">Download</a>
        </div>
            
        <div id="content">
          <h2>Upload</h2>
            <p>Upload file Anda dengan melengkapi form di bawah ini. Pilih jenis file sesuai departement. File yang bisa di Upload hanya file dengan ekstensi <b>.doc, .docx, .xls, .xlsx, .ppt, .pptx, .pdf, .rar, .zip, .jpg, .png, .mp4</b> dan besar file (file size) maksimal hanya 8 MB.</p>
            <p>*Jika terjadi error tipe file, silahkan convert tipe file ke format tipe file yang lain <a href="https://convertio.co/id/" target="_blank">Klik Disini</a> </p>
            
            <?php
    
      if($_POST['upload']){
        $allowed_ext  = array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf', 'rar', 'zip', 'jpg', 'png', 'mp4');
        $file_name    = $_FILES['file']['name'];        
        $file_ext   = strtolower(end(explode('.', $file_name)));        
        $file_size    = $_FILES['file']['size'];
        $file_tmp   = $_FILES['file']['tmp_name'];
        
        
        $jenis_file     = $_POST['jenis_file'];
        $tgl      = date("Y-m-d");
        
        if(in_array($file_ext, $allowed_ext) === true){
          if($file_size < 8388608){
            $lokasi = 'files/'.$file_name.'.'.$file_ext;
            move_uploaded_file($file_tmp, $lokasi);
            $in = mysql_query("INSERT INTO download VALUES(NULL, '$tgl', '$file_name', '$jenis_file', '$file_ext', '$file_size', '$lokasi')");
            if($in){
              echo '<div class="ok">SUCCESS: File berhasil di Upload!</div>';
            }else{
              echo '<div class="error">ERROR: Gagal upload file!</div>';
            }
          }else{
            echo '<div class="error">ERROR: Besar ukuran file (file size) maksimal 8 Mb!</div>';
          }
        }else{
          echo '<div class="error">ERROR: Ekstensi file tidak di izinkan!</div>';
        }
      }
      ?>            
            <p>
            <form action="" method="post" enctype="multipart/form-data">
            <table width="50%" align="center" border="0" bgcolor="#eee" cellpadding="2" cellspacing="0">
              
                <tr>
                 <div class="form-group">                
                    <label class="col-md-4 control-label" for="jenis_file" align="right">Jenis File</label>
                    
                    <div class="col-md-4">                     
                      <select name="jenis_file">
                        <option>-Pilih</option>
                        <?php 
                        $jenis_file = array("ISOBusinessDevelopment","ISOFacility","ISOFinance&Accounting","ISOGeneralService","ISOHumanResource&GeneralAffair","ISOPropertyManagement","FORMBusinessDevelopment","FORMFacility","FORMFinance&Accounting","FORMGeneralService","FORMHumanResource&GeneralAffair","FORMPropertyManagement","FOTOEvent","FOTOMeeting/Seminar","FOTOTraining","VIDEOEvent","VIDEOMeeting/Seminar","VIDEOTraining");
                        foreach($jenis_file as $j){
                          ?>
                          <option value="<?php echo $j?>">
                            <?php echo $j?>
                          </option>
                          <?php
                        }
                        ?>
                      </select>
                    </div><br>
                  </div>
                </tr>
                <tr>
                  <td width="40%" align="left"><b>Pilih File</b></td><td><b></b></td><td><input type="file" name="file" required /></td>
                </tr>
                <tr>
                  <td>&nbsp;</td><td>&nbsp;</td><td><input type="submit" name="upload" value="Upload" /></td>
                </tr>
            </table>
            </form>
            </p>
        </div>
    </div>

</body>
</html>

             
            </div>       
          </div>    
        <!-- end content -->
        </div>
        <!-- /. PAGE WRAPPER  -->
<?php
  include "../library/footeradmin.php";
?> 
