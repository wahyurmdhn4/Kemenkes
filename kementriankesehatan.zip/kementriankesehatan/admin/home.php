﻿<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headeradmin.php');
}else{
  include ('../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
  header("location:../index.php");
} ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2>Home</h2>                           
       <!-- /. ROW  -->
       <hr>     
       <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-6">           
          <div class="panel panel-back noti-box">
            <span class="icon-box bg-color-red set-icon">
              <i class="fa fa-user"></i>
            </span>
            <div class="text-box" >
              <?php
              $sql = "SELECT * FROM `tb_admin`";
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              ?>
              <p class=""><strong> <?php echo $jumlah?><br> Admin</strong></p>
              <p class="text-muted">Terdaftar</p>                      
            </div>
          </div>
        </div>              
        <div class="col-md-3 col-sm-6 col-xs-6">           
          <div class="panel panel-back noti-box">
            <span class="icon-box bg-color-green set-icon">
              <i class="fa fa-user"></i>
            </span>
            <div class="text-box" >
              <?php
              $sql = "SELECT * FROM `tb_kemenkes`";
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              ?>
              <p class=""><strong> <?php echo $jumlah?> Perusahaan</strong></p>
              <p class="text-muted">Terdaftar</p>                      
            </div>
          </div>
        </div>                                                
      </div>               
      <!-- END ROW -->
      <hr>     

       <?php

      $sql="SELECT * FROM `tb_kemenkes`";            
      $query = mysqli_query($con,$sql) or die(mysqli_error($con));
      $jumlah = mysqli_num_rows($query);

      if($jumlah==0){
        echo "Data Tidak ada";
      }else{
        ?>                

        <center>
          <div style="overflow-x:auto;">  
          <table id="example" class="table table-bordered" style="width:100%">
            <a href="form.php" class="btn btn-success pull-right">
                <span class="glyphicon glyphicon-upload"></span> Import Data
            </a>
            <thead>                                    
              <tr>
                <th>kode_obat</th>
                <th>nama_obat</th>
                <th>kemasan_dipersyaratkan</th>
                <th>industri_farmasi</th>
                <th>komitmen_nasional</th>
                <th>rko_nasional</th>
                <th>rko_lampung</th>
                <th>hps_lampung</th>
                <th>harga_lampung</th>
                <th>rko_banten</th>
                <th>hps_banten</th>
                <th>harga_banten</th>
                <th>rko_jakarta</th>
                <th>hps_jakarta</th>
                <th>harga_jakarta</th>
                <th>rko_jawabarat</th>
                <th>hps_jawabarat</th>
                <th>harga_jawabarat</th>
                <th>rko_jawatengah</th>
                <th>hps_jawatengah</th>
                <th>harga_jawatengah</th>
                <th>rko_yogyakarta</th>
                <th>hps_yogyakarta</th>
                <th>harga_yogyakarta</th>
                <th>rko_jawatimur</th>
                <th>hps_jawatimur</th>
                <th>harga_jawatimur</th>
                <th>rko_bali</th>
                <th>hps_bali</th>
                <th>harga_bali</th>
                <th>rko_sumaterautara</th>
                <th>hps_sumaterautara</th>
                <th>harga_sumaterautara</th>
                <th>rko_sumaterabarat</th>
                <th>hps_sumaterabarat</th>
                <th>harga_sumaterabarat</th>
                <th>rko_riau</th>
                <th>hps_riau</th>
                <th>harga_riau</th>
                <th>rko_jambi</th>
                <th>hps_jambi</th>
                <th>harga_jambi</th>
                <th>rko_sumateraselatan</th>
                <th>hps_sumateraselatan</th>
                <th>harga_sumateraselatan</th>
                <th>rko_bengkulu</th>
                <th>hps_bengkulu</th>
                <th>harga_bengkulu</th>
                <th>rko_kepulauanbangkabelitung</th>
                <th>hps_kepulauanbangkabelitung</th>
                <th>harga_kepulauanbangkabelitung</th>
                <th>rko_nusatenggarabarat</th>
                <th>hps_nusatenggarabarat</th>
                <th>harga_nusatenggarabarat</th>
                <th>rko_kepulauanriau</th>
                <th>hps_kepulauanriau</th>
                <th>harga_kepulauanriau</th>
                <th>rko_aceh</th>
                <th>hps_aceh</th>
                <th>harga_aceh</th>
                <th>rko_kalimantanbarat</th>
                <th>hps_kalimantanbarat</th>
                <th>harga_kalimantanbarat</th>
                <th>rko_kalimantanselatan</th>
                <th>hps_kalimantanselatan</th>
                <th>harga_kalimantanselatan</th>
                <th>rko_kalimantantimur</th>
                <th>hps_kalimantantimur</th>
                <th>harga_kalimantantimur</th>
                <th>rko_sulawesiutara</th>
                <th>hps_sulawesiutara</th>
                <th>harga_sulawesiutara</th>
                <th>rko_sulawesitengah</th>
                <th>hps_sulawesitengah</th>
                <th>harga_sulawesitengah</th>
                <th>rko_sulawesiselatan</th>
                <th>hps_sulawesiselatan</th>
                <th>harga_sulawesiselatan</th>
                <th>rko_kalimantanutara</th>
                <th>hps_kalimantanutara</th>
                <th>harga_kalimantanutara</th>
                <th>rko_kalimantantengah</th>
                <th>hps_kalimantantengah</th>
                <th>harga_kalimantantengah</th>
                <th>rko_sulawesitenggara</th>
                <th>hps_sulawesitenggara</th>
                <th>harga_sulawesitenggara</th>
                <th>rko_gorontalo</th>
                <th>hps_gorontalo</th>
                <th>harga_gorontalo</th>
                <th>rko_sulawesibarat</th>
                <th>hps_sulawesibarat</th>
                <th>harga_sulawesibarat</th>
                <th>rko_nusatenggaratimur</th>
                <th>hps_nusatenggaratimur</th>
                <th>harga_nusatenggaratimur</th>
                <th>rko_maluku</th>
                <th>hps_maluku</th>
                <th>harga_maluku</th>
                <th>rko_malukuutara</th>
                <th>hps_malukuutara</th>
                <th>harga_malukuutara</th>
                <th>rko_papuabarat</th>
                <th>hps_papuabarat</th>
                <th>harga_papuabarat</th>
                <th>rko_papua</th>
                <th>hps_papua</th>
                <th>harga_papua</th>
                <th>Action</th>                      
              </tr>
            </thead>

            <?php
            $no = 1;
            while($hasil = mysqli_fetch_object($query)){
              ?>

              <tr>
                <th><?php echo $hasil->kode_obat?></th>
                <th><?php echo $hasil->nama_obat?></th>
                <th><?php echo $hasil->kemasan_dipersyaratkan?></th>
                <th><?php echo $hasil->industri_farmasi?></th>
                <th><?php echo $hasil->komitmen_nasional?></th>
                <th><?php echo $hasil->rko_nasional?></th>
                <th><?php echo $hasil->rko_lampung?></th>
                <th><?php echo $hasil->hps_lampung?></th>
                <th><?php echo $hasil->harga_lampung?></th>
                <th><?php echo $hasil->rko_banten?></th>
                <th><?php echo $hasil->hps_banten?></th>
                <th><?php echo $hasil->harga_banten?></th>
                <th><?php echo $hasil->rko_jakarta?></th>
                <th><?php echo $hasil->hps_jakarta?></th>
                <th><?php echo $hasil->harga_jakarta?></th>
                <th><?php echo $hasil->rko_jawabarat?></th>
                <th><?php echo $hasil->hps_jawabarat?></th>
                <th><?php echo $hasil->harga_jawabarat?></th>
                <th><?php echo $hasil->rko_jawatengah?></th>
                <th><?php echo $hasil->hps_jawatengah?></th>
                <th><?php echo $hasil->harga_jawatengah?></th>
                <th><?php echo $hasil->rko_yogyakarta?></th>
                <th><?php echo $hasil->hps_yogyakarta?></th>
                <th><?php echo $hasil->harga_yogyakarta?></th>
                <th><?php echo $hasil->rko_jawatimur?></th>
                <th><?php echo $hasil->hps_jawatimur?></th>
                <th><?php echo $hasil->harga_jawatimur?></th>
                <th><?php echo $hasil->rko_bali?></th>
                <th><?php echo $hasil->hps_bali?></th>
                <th><?php echo $hasil->harga_bali?></th>
                <th><?php echo $hasil->rko_sumaterautara?></th>
                <th><?php echo $hasil->hps_sumaterautara?></th>
                <th><?php echo $hasil->harga_sumaterautara?></th>
                <th><?php echo $hasil->rko_sumaterabarat?></th>
                <th><?php echo $hasil->hps_sumaterabarat?></th>
                <th><?php echo $hasil->harga_sumaterabarat?></th>
                <th><?php echo $hasil->rko_riau?></th>
                <th><?php echo $hasil->hps_riau?></th>
                <th><?php echo $hasil->harga_riau?></th>
                <th><?php echo $hasil->rko_jambi?></th>
                <th><?php echo $hasil->hps_jambi?></th>
                <th><?php echo $hasil->harga_jambi?></th>
                <th><?php echo $hasil->rko_sumateraselatan?></th>
                <th><?php echo $hasil->hps_sumateraselatan?></th>
                <th><?php echo $hasil->harga_sumateraselatan?></th>
                <th><?php echo $hasil->rko_bengkulu?></th>
                <th><?php echo $hasil->hps_bengkulu?></th>
                <th><?php echo $hasil->harga_bengkulu?></th>
                <th><?php echo $hasil->rko_kepulauanbangkabelitung?></th>
                <th><?php echo $hasil->hps_kepulauanbangkabelitung?></th>
                <th><?php echo $hasil->harga_kepulauanbangkabelitung?></th>
                <th><?php echo $hasil->rko_nusatenggarabarat?></th>
                <th><?php echo $hasil->hps_nusatenggarabarat?></th>
                <th><?php echo $hasil->harga_nusatenggarabarat?></th>
                <th><?php echo $hasil->rko_kepulauanriau?></th>
                <th><?php echo $hasil->hps_kepulauanriau?></th>
                <th><?php echo $hasil->harga_kepulauanriau?></th>
                <th><?php echo $hasil->rko_aceh?></th>
                <th><?php echo $hasil->hps_aceh?></th>
                <th><?php echo $hasil->harga_aceh?></th>
                <th><?php echo $hasil->rko_kalimantanbarat?></th>
                <th><?php echo $hasil->hps_kalimantanbarat?></th>
                <th><?php echo $hasil->harga_kalimantanbarat?></th>
                <th><?php echo $hasil->rko_kalimantanselatan?></th>
                <th><?php echo $hasil->hps_kalimantanselatan?></th>
                <th><?php echo $hasil->harga_kalimantanselatan?></th>
                <th><?php echo $hasil->rko_kalimantantimur?></th>
                <th><?php echo $hasil->hps_kalimantantimur?></th>
                <th><?php echo $hasil->harga_kalimantantimur?></th>
                <th><?php echo $hasil->rko_sulawesiutara?></th>
                <th><?php echo $hasil->hps_sulawesiutara?></th>
                <th><?php echo $hasil->harga_sulawesiutara?></th>
                <th><?php echo $hasil->rko_sulawesitengah?></th>
                <th><?php echo $hasil->hps_sulawesitengah?></th>
                <th><?php echo $hasil->harga_sulawesitengah?></th>
                <th><?php echo $hasil->rko_sulawesiselatan?></th>
                <th><?php echo $hasil->hps_sulawesiselatan?></th>
                <th><?php echo $hasil->harga_sulawesiselatan?></th>
                <th><?php echo $hasil->rko_kalimantanutara?></th>
                <th><?php echo $hasil->hps_kalimantanutara?></th>
                <th><?php echo $hasil->harga_kalimantanutara?></th>
                <th><?php echo $hasil->rko_kalimantantengah?></th>
                <th><?php echo $hasil->hps_kalimantantengah?></th>
                <th><?php echo $hasil->harga_kalimantantengah?></th>
                <th><?php echo $hasil->rko_sulawesitenggara?></th>
                <th><?php echo $hasil->hps_sulawesitenggara?></th>
                <th><?php echo $hasil->harga_sulawesitenggara?></th>
                <th><?php echo $hasil->rko_gorontalo?></th>
                <th><?php echo $hasil->hps_gorontalo?></th>
                <th><?php echo $hasil->harga_gorontalo?></th>
                <th><?php echo $hasil->rko_sulawesibarat?></th>
                <th><?php echo $hasil->hps_sulawesibarat?></th>
                <th><?php echo $hasil->harga_sulawesibarat?></th>
                <th><?php echo $hasil->rko_nusatenggaratimur?></th>
                <th><?php echo $hasil->hps_nusatenggaratimur?></th>
                <th><?php echo $hasil->harga_nusatenggaratimur?></th>
                <th><?php echo $hasil->rko_maluku?></th>
                <th><?php echo $hasil->hps_maluku?></th>
                <th><?php echo $hasil->harga_maluku?></th>
                <th><?php echo $hasil->rko_malukuutara?></th>
                <th><?php echo $hasil->hps_malukuutara?></th>
                <th><?php echo $hasil->harga_malukuutara?></th>
                <th><?php echo $hasil->rko_papuabarat?></th>
                <th><?php echo $hasil->hps_papuabarat?></th>
                <th><?php echo $hasil->harga_papuabarat?></th>
                <th><?php echo $hasil->rko_papua?></th>
                <th><?php echo $hasil->hps_papua?></th>
                <th><?php echo $hasil->harga_papua?></th>
                <td>
                  <a class="btn btn-primary" href="ubahpendidik.php?id=<?php echo $hasil->id_pendidik?>"><span class="fa fa-pencil"></span></a>
                  <a class="btn btn-danger" href="../proses/do_hapus_mt_agama.php?id=<?php echo $hasil->agama?>" onclick="return confirm('Anda yakin mau hapus <?php echo $hasil->agama?> ?')"><span class="fa fa-trash"></span></a>
                </td>                        
              </tr>

              <?php 
              $no++;
            } ?>
            <tfoot>                                        
              <tr>
                <th>kode_obat</th>
                <th>nama_obat</th>
                <th>kemasan_dipersyaratkan</th>
                <th>industri_farmasi</th>
                <th>komitmen_nasional</th>
                <th>rko_nasional</th>
                <th>rko_lampung</th>
                <th>hps_lampung</th>
                <th>harga_lampung</th>
                <th>rko_banten</th>
                <th>hps_banten</th>
                <th>harga_banten</th>
                <th>rko_jakarta</th>
                <th>hps_jakarta</th>
                <th>harga_jakarta</th>
                <th>rko_jawabarat</th>
                <th>hps_jawabarat</th>
                <th>harga_jawabarat</th>
                <th>rko_jawatengah</th>
                <th>hps_jawatengah</th>
                <th>harga_jawatengah</th>
                <th>rko_yogyakarta</th>
                <th>hps_yogyakarta</th>
                <th>harga_yogyakarta</th>
                <th>rko_jawatimur</th>
                <th>hps_jawatimur</th>
                <th>harga_jawatimur</th>
                <th>rko_bali</th>
                <th>hps_bali</th>
                <th>harga_bali</th>
                <th>rko_sumaterautara</th>
                <th>hps_sumaterautara</th>
                <th>harga_sumaterautara</th>
                <th>rko_sumaterabarat</th>
                <th>hps_sumaterabarat</th>
                <th>harga_sumaterabarat</th>
                <th>rko_riau</th>
                <th>hps_riau</th>
                <th>harga_riau</th>
                <th>rko_jambi</th>
                <th>hps_jambi</th>
                <th>harga_jambi</th>
                <th>rko_sumateraselatan</th>
                <th>hps_sumateraselatan</th>
                <th>harga_sumateraselatan</th>
                <th>rko_bengkulu</th>
                <th>hps_bengkulu</th>
                <th>harga_bengkulu</th>
                <th>rko_kepulauanbangkabelitung</th>
                <th>hps_kepulauanbangkabelitung</th>
                <th>harga_kepulauanbangkabelitung</th>
                <th>rko_nusatenggarabarat</th>
                <th>hps_nusatenggarabarat</th>
                <th>harga_nusatenggarabarat</th>
                <th>rko_kepulauanriau</th>
                <th>hps_kepulauanriau</th>
                <th>harga_kepulauanriau</th>
                <th>rko_aceh</th>
                <th>hps_aceh</th>
                <th>harga_aceh</th>
                <th>rko_kalimantanbarat</th>
                <th>hps_kalimantanbarat</th>
                <th>harga_kalimantanbarat</th>
                <th>rko_kalimantanselatan</th>
                <th>hps_kalimantanselatan</th>
                <th>harga_kalimantanselatan</th>
                <th>rko_kalimantantimur</th>
                <th>hps_kalimantantimur</th>
                <th>harga_kalimantantimur</th>
                <th>rko_sulawesiutara</th>
                <th>hps_sulawesiutara</th>
                <th>harga_sulawesiutara</th>
                <th>rko_sulawesitengah</th>
                <th>hps_sulawesitengah</th>
                <th>harga_sulawesitengah</th>
                <th>rko_sulawesiselatan</th>
                <th>hps_sulawesiselatan</th>
                <th>harga_sulawesiselatan</th>
                <th>rko_kalimantanutara</th>
                <th>hps_kalimantanutara</th>
                <th>harga_kalimantanutara</th>
                <th>rko_kalimantantengah</th>
                <th>hps_kalimantantengah</th>
                <th>harga_kalimantantengah</th>
                <th>rko_sulawesitenggara</th>
                <th>hps_sulawesitenggara</th>
                <th>harga_sulawesitenggara</th>
                <th>rko_gorontalo</th>
                <th>hps_gorontalo</th>
                <th>harga_gorontalo</th>
                <th>rko_sulawesibarat</th>
                <th>hps_sulawesibarat</th>
                <th>harga_sulawesibarat</th>
                <th>rko_nusatenggaratimur</th>
                <th>hps_nusatenggaratimur</th>
                <th>harga_nusatenggaratimur</th>
                <th>rko_maluku</th>
                <th>hps_maluku</th>
                <th>harga_maluku</th>
                <th>rko_malukuutara</th>
                <th>hps_malukuutara</th>
                <th>harga_malukuutara</th>
                <th>rko_papuabarat</th>
                <th>hps_papuabarat</th>
                <th>harga_papuabarat</th>
                <th>rko_papua</th>
                <th>hps_papua</th>
                <th>harga_papua</th>
                <th>Action</th>                                                               
              </tr>
            </tfoot>
          </table>
        <?php } ?>
    </div>
    </div> 
    <!-- /. PAGE INNER  -->
  </div>
  <!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  -->  

<?php
include "../library/footeradmin.php";
?>      