<?php
	include("../../mysql.php");
	include('../../config.php');
	$id = $_GET["id"];
	$sql = "DELETE FROM `download` WHERE `id`='".$id."' ";
	
	if(mysql_query($sql));
	header("location:../download.php?salah=<strong> Berhasil Menghapus!");

?>