<?php 
	include "../../koneksi.php";
	

	$username =$_SESSION["admin"];
	$password = $_POST["password"];
	$passwordbaru = $_POST["passwordbaru"];
	$ulangi = $_POST["ulangi"];


	$sql = "SELECT * FROM `tb_admin` WHERE `username` ='".$username."' AND `password` ='".md5($password)."' "; 
	$query = mysqli_query($con,$sql) or die(mysqli_error($con)
	);
	$jumlah = mysqli_num_rows($query);

	
	if($jumlah==0){
		header("location:../ubah_sandi.php?salah=Kata sandi lama salah!");
	}else if($passwordbaru==""){
		header("location:../ubah_sandi.php?salah=Harap isi kata sandi baru!");
	}else if($ulangi!=$passwordbaru){
		header("location:../ubah_sandi.php?salah=Harap ulangi kata sandi sama dengan kata sandi baru!");
	}else{
		$sql="UPDATE `tb_admin` SET
		`password`='".md5($passwordbaru)."'
		WHERE `username`='".$username."'";
		//die($sql);
		mysqli_query($con,$sql) or die(mysqli_error($con));
		header("location:../ubah_sandi.php?sukses= Kata sandi berhasil di ubah!");
	}
	
?>