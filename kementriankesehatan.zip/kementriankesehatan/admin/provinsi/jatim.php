<?php 
include "../../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../../library/headerprovinsi.php');
}else{
  include ('../../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
  header("location:../../index.php");
} ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2>Home</h2>                           
       <!-- /. ROW  -->
       <hr>     
       <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-6">           
          <div class="panel panel-back noti-box">
            <span class="icon-box bg-color-red set-icon">
              <i class="fa fa-user"></i>
            </span>
            <div class="text-box" >
              <?php
              $sql = "SELECT * FROM `tb_admin`";
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              ?>
              <p class=""><strong> <?php echo $jumlah?><br> Admin</strong></p>
              <p class="text-muted">Terdaftar</p>                      
            </div>
          </div>
        </div>              
        <div class="col-md-3 col-sm-6 col-xs-6">           
          <div class="panel panel-back noti-box">
            <span class="icon-box bg-color-green set-icon">
              <i class="fa fa-user"></i>
            </span>
            <div class="text-box" >
              <?php
              $sql = "SELECT * FROM `tb_kemenkes`";
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              ?>
              <p class=""><strong> <?php echo $jumlah?> Perusahaan</strong></p>
              <p class="text-muted">Terdaftar</p>                      
            </div>
          </div>
        </div>                                                
      </div>               
      <!-- END ROW -->
      <hr>     

       <?php

      $sql="SELECT * FROM `tb_kemenkes`";            
      $query = mysqli_query($con,$sql) or die(mysqli_error($con));
      $jumlah = mysqli_num_rows($query);

      if($jumlah==0){
        echo "Data Tidak ada";
      }else{
        ?>                

        <center>
          <div style="overflow-x:auto;">
          <table id="example" class="table table-bordered" style="width:100% font-size: 10%;">
            <thead>                                    
              <tr>                
                <th>kode_obat</th>
                <th>nama_obat</th>
                <th>kemasan_dipersyaratkan</th>
                <th>industri_farmasi</th>
                <th>komitmen_nasional</th>                
                <th>rko_jawatimur</th>
                <th>hps_jawatimur</th>
                <th>harga_jawatimur</th>                
                <th>Action</th>                      
              </tr>
            </thead>

            <?php
            $no = 1;
            while($hasil = mysqli_fetch_object($query)){
              ?>

              <tr>                
                <th><?php echo $hasil->kode_obat?></th>
                <th><?php echo $hasil->nama_obat?></th>
                <th><?php echo $hasil->kemasan_dipersyaratkan?></th>
                <th><?php echo $hasil->industri_farmasi?></th>
                <th><?php echo $hasil->komitmen_nasional?></th>                
                <th><?php echo $hasil->rko_jawatimur?></th>
                <th><?php echo $hasil->hps_jawatimur?></th>
                <th><?php echo $hasil->harga_jawatimur?></th>                
                <td>
                  <a class="btn btn-primary" href="ubahpendidik.php?id=<?php echo $hasil->id_pendidik?>"><span class="fa fa-pencil"></span></a>
                  <a class="btn btn-danger" href="../../proses/do_hapus_mt_agama.php?id=<?php echo $hasil->agama?>" onclick="return confirm('Anda yakin mau hapus <?php echo $hasil->agama?> ?')"><span class="fa fa-trash"></span></a>
                </td>                        
              </tr>

              <?php 
              $no++;
            } ?>
            <tfoot>                                        
              <tr>                
                <th>kode_obat</th>
                <th>nama_obat</th>
                <th>kemasan_dipersyaratkan</th>
                <th>industri_farmasi</th>
                <th>komitmen_nasional</th>                
                <th>rko_jawatimur</th>
                <th>hps_jawatimur</th>
                <th>harga_jawatimur</th>                
                <th>Action</th>                                    
              </tr>
            </tfoot>
          </table>
        <?php } ?>
    </div> 
    <!-- /. PAGE INNER  -->
  </div>
  <!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  -->  

<?php
include "../../library/footerprovinsi.php";
?>      