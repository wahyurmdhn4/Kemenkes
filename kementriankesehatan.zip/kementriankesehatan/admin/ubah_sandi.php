<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headeradmin.php');
}else{
  include ('../library/header.php');
  }
 ?> 

<?php 
 if(empty($_SESSION["admin"])){
    header("location:../index.php");
  } 
  ?>
  <!-- /. NAV SIDE  -->
  <div id="page-wrapper" >
  	<div id="page-inner">
  		<div class="row">

  			<form  action="proses/do_ubahpassword.php" method="post" class="form-horizontal">
  				<div class="col-md-12">
            <h2>Ubah Password</h2>
            <hr>

  					<?php
  					if(!empty($_GET["salah"])){
  						echo $_GET["salah"];
  					}
  					if(!empty($_GET["sukses"])){
  						echo $_GET["sukses"];
  					}
  					?>

  					<br><br>
  					<!-- Form Name -->  					

	  					<!-- Password input-->
					<div class="form-group">
						<label class="col-md-4 control-label" for="password">Kata Sandi Lama</label>
						<div class="col-md-4">
							<input id="txt_lama" name="password" type="password" placeholder="Kata Sandi Lama" class="form-control input-md">

						</div>
					</div>

					<!-- Password input-->
					<div class="form-group">
						<label class="col-md-4 control-label" for="passwordbaru">Kata Sandi Baru</label>
						<div class="col-md-4">
							<input id="txt_baru" name="passwordbaru" type="password" placeholder="Kata Sandi Baru" class="form-control input-md">

						</div>
					</div>

					<!-- Password input-->
					<div class="form-group">
						<label class="col-md-4 control-label" for="ulangi">Ulangi Kata Sandi</label>
						<div class="col-md-4">
							<input id="txt_ulangi" name="ulangi" type="password" placeholder="Ulangi Kata Sandi" class="form-control input-md">

						</div>
					</div>

  					<!-- Button -->
  					<div class="form-group">
  						<label class="col-md-6 control-label" for=""></label>
  						<div class="col-md-4" >
  							<button id="" name="" class="btn btn-primary">Ubah Sandi</button>
  						</div>
  					</div>

  				</div>	
  			</form>
  		</div>	
  	</div>
  </div>	

<?php  
 include "../library/footeradmin.php";
?> 		