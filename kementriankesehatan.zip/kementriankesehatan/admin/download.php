<?php 
include ('../mysql.php');
include('../config.php');
include'../koneksi.php';
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headeradmin.php');
}else{
  include ('../library/header.php');
}

 ?> 

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../index.php");
    } ?>


        <div id="page-wrapper" >
          <div id="page-inner">
              <div class="row">
                <div class="col-md-12">
                 <h2>Pendaftaran Dokumentasi</h2>                          
               </div>
             </div>              
             <!-- /. ROW  -->
             <hr />
             <div class="row">
              <!-- start content -->
<!DOCTYPE html>
<html>
<head>
    <title>Upload dan Download File</title>    
</head>
<style>
 @charset "utf-8";
/* CSS Document */

h1, h2, h3 {
  margin:0;
  padding:0;
}

#container {
  width:1100px;
  margin:20px auto;
  padding:10px;
  background-color:#fff;
  box-shadow:0px 0px 3px #000;
}

#header {
  text-align:center;
}

#menu {
  text-align:center;
  margin:15px 0px;
  border-top:1px solid #CCC;
  border-bottom:1px solid #CCC;
}

  #menu a {
    display:inline-block;
    padding:5px 10px;
    text-decoration:none;
    color:#000;
    font-weight:bold;
  }
  
    #menu a:hover {
      background-color:#CCC;
    }
    
    #menu a.active {
      background-color:#CCC;
    }

.table, th, td {
  border-collapse:collapse;
  border:1px solid #ccc;
}

  .table th {
    background-color:#CCC;
  }
  
.error {
  border:1px solid #FF8080;
  background-color:#FFCECE;
  padding:3px;
  margin:5px 0px;
  text-align:center;
}

.ok {
  border:1px solid #80FF80;
  background-color:#CFC;
  padding:3px;
  margin:5px 0px;
  text-align:center;
} 
</style>

<body>

    <div class="col-md-12">
        <div id="header">
            <h1>Upload dan Download File</h1>
            <span>Dibuat oleh Rifki Abdillah</span>
        </div>    
        <div id="menu">
          
            <a href="upload.php">Upload</a>
            <a href="download.php" class="active">Download</a>
        </div>
        
        <div id="content">
          <h2>Download</h2>
            <p>Silahkan download file yang sudah di Upload di website ini. Untuk men-Download Anda bisa mengklik Nama file yang diinginkan.</p>
            
            <p>
            <table id="example" class="table table-bordered" style="width:100%">
            <thead>
              <tr>
                  <th width="30">No.</th>
                    <th width="30">ID.</th>
                    <th width="80">Tgl. Upload</th>
                    <th>Nama File</th>
                    <th width="200"><center>Jenis File</center></th>
                    <th width="70">Tipe</th>
                    <th width="70">Ukuran</th>
                    <th width="70">Aksi</th>
                </tr>
                </thead>
                <tfoot>
              <tr>
                  <th width="30">No.</th>
                    <th width="30">ID.</th>
                    <th width="80">Tgl. Upload</th>
                    <th>Nama File</th>
                    <th width="200"><center>Jenis File</center></th>
                    <th width="70">Tipe</th>
                    <th width="70">Ukuran</th>
                    <th width="70">Aksi</th>
                </tr>
                </tfoot>
                <?php                   
        $sql = mysql_query("SELECT * FROM download ORDER BY id ASC");
        if(mysql_num_rows($sql) > 0){
          $no = 1;
          while($data = mysql_fetch_assoc($sql)){
            echo '
            <tr bgcolor="#fff">
              <td align="center">'.$no.'</td>
              <td align="center">'.$data['id'].'</td>
              <td align="center">'.$data['tanggal_upload'].'</td>
              <td><a href="'.$data['file'].'">'.$data['nama_file'].'</a></td>
              <td align="center">'.$data['jenis_file'].'</td> 
              <td align="center">'.$data['tipe_file'].'</td>
              <td align="center">'.formatBytes($data['ukuran_file']).'</td>
              
                            <td align="center"><a class="btn btn-danger" href="proses/do_hapus_file.php?id= '.$data['id'].'" <span class="fa fa-trash"></span> Hapus</a></td>
                            
            </tr>
            ';

            $no++;
          }
        }else{
          echo '
          <tr bgcolor="#fff">
            <td align="center" colspan="4" align="center">Tidak ada data!</td>
          </tr>
          ';
        }
        ?>

            </table>
            </p>
        </div>
    </div>

</body>
</html>

             
            </div>       
          </div>    
        <!-- end content -->
        </div>
        <!-- /. PAGE WRAPPER  -->
<?php
  include "../library/footeradmin.php";
?> 
