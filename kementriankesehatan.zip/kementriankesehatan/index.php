<?php 
include 'koneksi.php';
include "library/header.php";

 ?> 
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>KEMENKES</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/mark.css" rel="stylesheet">
		<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
		<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
		<script src="js/ie-emulation-modes-warning.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand page-scroll" href="#page-top"><img src="images/kemenkes.png"></a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>												
						<li>
							<a class="page-scroll" href="#kontak">Kontak</a>
						</li>						
						<li>
							<a class="page-scroll" href="#login">Login</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
		<!-- Header -->
		<header>
			<div class="container">
				<div class="slider-container">
					<div class="intro-text">
						<div class="intro-lead-in"><mark> Untuk Indonesia  </mark></div><br>						
						<div class="intro-heading"><mark> YANG LEBIH SEHAT </mark></div>				
						<a href="#login" class="page-scroll btn btn-xl">Get Started</a>											
					</div>
				</div>
			</div>
		</header>

		<section id="login" class="light-bg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>Login</h2>
							<p>Silahkan login terlebih dahulu untuk mendapatkan akses lebih.</p>
							<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
								<div class="panel panel-default">
									<div class="panel-heading">
										<strong>  KEMENKES </strong>  
									</div>
									<div class="panel-body">
										<form role="form" action="do_proseslogin.php" method="post">									
											<br />
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
												<input id="username" name="username" type="text" class="form-control" placeholder="Your Username " />
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
												<input id="password" name="password" type="password" class="form-control"  placeholder="Your Password" />
											</div>
											<div class="form-group">
												<label class="checkbox-inline">
													<input type="checkbox" /> Remember me
												</label>												
											</div>

											<button type="submit" class="btn btn-primary">Masuk </button>
											<hr />
											
										</form>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<!-- /.container -->
		</section>										
		
		<section id="kontak">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>Kontak Kami</h2>
							<p>Jika Anda memiliki beberapa Pertanyaan atau butuh Bantuan! Silakan Hubungi Kami!.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3">						
					</div>
					<div class="col-md-3">
						<h3>Kantor Kami</h3>
						<p><i class="fa fa-building"></i> Jalan H.R. Rasuna Said Blok X.5 Kav. 4-9 Jakarta Selatan 12950 DKI Jakarta, Indonesia</p>
						<p><i class="fa fa-phone"></i> 1500567</p>
						<p><i class="fa fa-envelope"></i> kontak@kemkes.go.id</p>
					</div>
					<div class="col-md-3">
						<h3>Jam Kerja</h3>
						<p><i class="fa fa-clock-o"></i> <span class="day">Senin-Jumat: </span><span>08.00 s/d 15.00</span></p>
						<p><i class="fa fa-clock-o"></i> <span class="day">Sabtu: </span><span>08.00 s/d 12.00</span></p>
						<p><i class="fa fa-clock-o"></i> <span class="day">Minggu: </span><span>Libur</span></p>
					</div>					
				</div>
			</div>
		</section>
		<p id="back-top">
			<a href="#top"><i class="fa fa-angle-up"></i></a>
		</p>
		<footer>
			<div class="container text-center">
				<p>Copyright (c) 2019 <span>- Kementerian Kesehatan - </span>KEMENKES</p>
			</div>
		</footer>	
		
		<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/cbpAnimatedHeader.js"></script>
		<script src="js/theme-scripts.js"></script>
		
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script src="js/ie10-viewport-bug-workaround.js"></script>		
	</body>
</html>

<?php
	include "library/footer.php"
?>