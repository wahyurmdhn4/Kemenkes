

<script src="js/jquery.cycle.all.js"></script>
<script src="js/jquery.jcarousel.min.js"></script>
<script src="js/jcarousel.basic.js"></script>	
<script src="js/datatables.js"></script>


<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>

