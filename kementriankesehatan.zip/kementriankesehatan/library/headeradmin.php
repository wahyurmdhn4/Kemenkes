<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ADMIN - KEMENKES</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/fontawesome-all.min.css">
    <link rel="stylesheet" href="../css/jcarousel.basic.css">
    <!-- <link rel="stylesheet" href="../css/baris.css"> -->

    <link rel="stylesheet" href="../plugin/jquery-ui-1.12.1.custom/jquery-ui.css">

    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' rel='stylesheet' type='text/css'> 
    <link href='https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css' rel='stylesheet' type='text/css'> 
  <!-- BOOTSTRAP STYLES-->
  <link href="../assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FONTAWESOME STYLES-->
  <link href="../assets/css/font-awesome.css" rel="stylesheet" />
  <!-- CUSTOM STYLES-->
  <link href="../assets/css/custom.css" rel="stylesheet" />
  <!-- GOOGLE FONTS-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

  <link href="../css/alert.css" rel="stylesheet" />

  <link rel="shortcut icon" href="../images/logo.png">       
  <script type="text/javascript" src="../assets/chartjs/Chart.js"></script>
  <script type="text/javascript" src="../assets/chartjs/Chart.min.js"></script>
  <script type="text/javascript" src="../assets/chartjs/Chart.bundle.js"></script>
  <script type="text/javascript" src="../assets/chartjs/Chart.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.3.0/Chart.bundle.js"></script>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand" href="home.php">KEMENKES</a> 
            </div>
            <div style="color: white;
            padding: 15px 50px 5px 50px;
            float: right;
            font-size: 16px;"> &nbsp; 
            <a href="ubah_sandi.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-key fa-1x"></i> Change Password</a> 
            <a href="../admin/proses/do_logout.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-sign-out fa-1x"></i> Logout</a>                         
            </div>            
            <div style="color: white;
            padding: 15px 50px 5px 50px;
            float: left;
            font-size: 16px;"> &nbsp;             
           
            
            </div>            
        </nav>   
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="text-center">
                        <img src="../assets/img/find_user.png" class="user-image img-responsive"/>
                    </li>   
                    <li>
                        <a class="active-menu" href="home.php"><center> Welcome, <?php echo $_SESSION['admin']; ?></center></a>
                    </li>                                    
                    <li>
                        <a class="" href="home.php"><i class="fa fa-dashboard fa-1x"></i> Dashboard</a>
                    </li>
                    <!-- <li>
                        <a  href="upload.php"><i class="fa fa-download fa-1x"></i> Upload/Download</a>
                    </li>  -->                          
                    <li>
                        <a href="#"><i class="fa fa-user fa-1x"></i>Manage Users<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="kelolausersadmin.php">Manage Users Admin</a>
                            </li>
                            <!-- <li>
                                <a href="kelolausersperusahaan.php">Manage Users Perusahaan</a>
                            </li>    -->                        
                        </ul>
                    </li>                                          
                    <li>
                        <a href="#"><i class="fa fa-user fa-1x"></i>Pilih Provinsi<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                          
                            <li>
                               <a href="provinsi/aceh.php">Aceh</a>
                            </li>
                            <li>
                               <a href="provinsi/bali.php">Bali</a>
                            </li>    
                             <li>
                               <a href="provinsi/banten.php">Banten</a>
                            </li>         
                            <li>
                               <a href="provinsi/bengkulu.php">Bengkulu</a>
                            </li>     
                            <li>
                               <a href="provinsi/dkijakarta.php">DKI Jakarta</a>
                            </li>  
                             <li>
                               <a href="provinsi/gorontalo.php">Gorontalo</a>
                            </li>   
                            <li>
                               <a href="provinsi/jambi.php">Jambi</a>
                            </li>
                            <li>
                               <a href="provinsi/jabar.php">Jawa Barat</a>
                            </li> 
                            <li>
                               <a href="provinsi/jateng.php">Jawa Tengah</a>
                            </li>   
                            <li>
                               <a href="provinsi/jatim.php">Jawa Timur</a>
                            </li>                                 
                            <li>
                               <a href="provinsi/kalbar.php">Kalimantan Barat</a>
                            </li>    
                            <li>
                               <a href="provinsi/kalsel.php">Kalimantan Selatan</a>
                            </li>  
                            <li>
                               <a href="provinsi/kalteng.php">Kalimantan Tengah</a>
                            </li>   
                            <li>
                               <a href="provinsi/kaltim.php">Kalimantan Timur</a>
                            </li>                                                                    
                            <li>
                               <a href="provinsi/kalut.php">Kalimantan Utara</a>
                            </li>  
                            <li>
                               <a href="provinsi/bangkabelitung.php">Kepulauan Bangka Belitung</a>
                            </li>   
                            <li>
                               <a href="provinsi/kepriau.php">Kepulauan Riau</a>
                            </li>    
                            <li>
                                <a href="provinsi/lampung.php">Lampung</a>
                            </li>  
                            <li>
                               <a href="provinsi/maluku.php">Maluku</a>
                            </li> 
                             <li>
                               <a href="provinsi/malut.php">Maluku Utara</a>
                            </li>     
                            <li>
                               <a href="provinsi/ntb.php">Nusa Tenggara Barat</a>
                            </li>  
                             <li>
                               <a href="provinsi/ntt.php">Nusa Tenggara Timur</a>
                            </li>  
                            <li>
                               <a href="provinsi/papua.php">Papua</a>
                            </li>    
                            <li>
                               <a href="provinsi/papbar.php">Papua Barat</a>
                            </li>   
                            <li>
                               <a href="provinsi/riau.php">Riau</a>
                            </li>  
                             <li>
                               <a href="provinsi/sulbar.php">Sulawesi Barat</a>
                            </li>      
                            <li>
                               <a href="provinsi/sulsel.php">Sulawesi Selatan</a>
                            </li>   
                            <li>
                               <a href="provinsi/sulteng.php">Sulawesi Tengah</a>
                            </li> 
                            <li>
                               <a href="provinsi/sultenggara.php">Sulawesi Tenggara</a>
                            </li>       
                            <li>
                               <a href="provinsi/sulut.php">Sulawesi Utara</a>
                            </li>    
                            <li>
                               <a href="provinsi/sumbar.php">Sumatera Barat</a>
                            </li>
                            <li>
                               <a href="provinsi/sumsel.php">Sumatera Selatan</a>
                            </li> 
                            <li>
                               <a href="provinsi/sumut.php">Sumatera Utara</a>
                            </li>  
                            <li>
                               <a href="provinsi/yogyakarta.php">Yogyakarta</a>
                            </li>                        
                                    
                        </ul>
                    </li>                                          

                </ul>                
            </div>
            
        </nav>  
